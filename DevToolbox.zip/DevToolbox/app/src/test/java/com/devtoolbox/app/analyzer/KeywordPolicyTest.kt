package com.devtoolbox.app.analyzer

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class KeywordPolicyTest {
    private fun isV(returnType: String) = returnType == "V"

    @Test fun vFilterRejectsVoid() {
        assertTrue(isV("V"))
        assertFalse(isV("Z"))
        assertFalse(isV("I"))
    }

    @Test fun criticalKeywordsArePresentInSpecData() {
        val data = java.io.File("src/main/assets/keywords.dat").readText()
        val required = listOf("isVip", "isVIP", "is_vip", "isPremium", "isPro", "purchase", "billing", "subscription", "entitlement", "paywall", "trial", "expiration", "isValid", "remainingDays")
        required.forEach { assertTrue("Missing $it", data.lines().any { line -> line.equals(it, ignoreCase = true) }) }
    }
}
