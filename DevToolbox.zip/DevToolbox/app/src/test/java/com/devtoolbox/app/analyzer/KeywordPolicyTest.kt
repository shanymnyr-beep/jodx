package com.devtoolbox.app.analyzer

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class KeywordPolicyTest {
    private fun isV(returnType: String) = returnType == "V"

    @Test fun vFilterRejectsVoid() {
        assertTrue(isV("V"))
        assertFalse(isV("Z"))
        assertFalse(isV("I"))
    }

    private fun projectDirForTest(): java.io.File {
        val userDir = java.io.File(System.getProperty("user.dir"))
        val moduleAsset = java.io.File(userDir, "src/main/assets/keywords.dat")
        if (moduleAsset.isFile) return userDir
        val rootAsset = java.io.File(userDir, "app/src/main/assets/keywords.dat")
        if (rootAsset.isFile) return java.io.File(userDir, "app")
        error("keywords.dat not found from ${userDir.absolutePath}")
    }

    @Test fun criticalKeywordsArePresentInSpecData() {
        val data = java.io.File(projectDirForTest(), "src/main/assets/keywords.dat").readText()
        val required = listOf("isVip", "isVIP", "is_vip", "isPremium", "isPro", "purchase", "billing", "subscription", "entitlement", "paywall", "trial", "expiration", "isValid", "remainingDays")
        required.forEach { assertTrue("Missing $it", data.lines().any { line -> line.equals(it, ignoreCase = true) }) }
    }
}
