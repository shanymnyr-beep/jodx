package com.devtoolbox.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import com.devtoolbox.app.ui.components.DangerButton
import com.devtoolbox.app.ui.components.MultiLineField
import com.devtoolbox.app.ui.components.OutputCard
import com.devtoolbox.app.ui.components.PrimaryButton
import com.devtoolbox.app.ui.components.SectionLabel
import com.devtoolbox.app.ui.components.ToolScaffold
import java.util.regex.Pattern

@Composable
fun RegexTesterScreen(onBack: () -> Unit) {
    var pattern by remember { mutableStateOf("") }
    var test by remember { mutableStateOf("") }
    var caseInsensitive by remember { mutableStateOf(false) }
    var multiline by remember { mutableStateOf(false) }
    var dotAll by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }

    ToolScaffold(title = "اختبار Regex", onBack = onBack) { mod ->
        SectionLabel("النمط (Pattern)")
        OutlinedTextField(
            value = pattern,
            onValueChange = { pattern = it },
            label = { Text("مثال: \\d+") },
            singleLine = true,
            textStyle = MaterialTheme.typography.bodyMedium.copy(fontFamily = FontFamily.Monospace),
            modifier = mod
        )
        Spacer(Modifier.height(10.dp))
        SectionLabel("نص الاختبار")
        MultiLineField(test, { test = it }, "النص المراد البحث فيه", minHeight = 100)
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            ToggleChip("غير حساس", caseInsensitive) { caseInsensitive = it }
            ToggleChip("متعدد الأسطر", multiline) { multiline = it }
            ToggleChip("DotAll", dotAll) { dotAll = it }
        }
        Spacer(Modifier.height(10.dp))
        PrimaryButton("اختبار", onClick = {
            if (pattern.isBlank()) { message = "✗ أدخل نمطاً"; result = ""; return@PrimaryButton }
            runCatching {
                var flags = 0
                if (caseInsensitive) flags = flags or Pattern.CASE_INSENSITIVE
                if (multiline) flags = flags or Pattern.MULTILINE
                if (dotAll) flags = flags or Pattern.DOTALL
                val matcher = Pattern.compile(pattern, flags).matcher(test)
                val sb = StringBuilder()
                var count = 0
                while (matcher.find()) {
                    count++
                    sb.append("[$count] \"${matcher.group()}\"  @ ${matcher.start()}-${matcher.end()}\n")
                }
                message = "✓ عدد المطابقات: $count"
                result = if (count == 0) "لا توجد مطابقات" else sb.toString().trimEnd('\n')
            }.onFailure {
                message = "✗ ${it.message ?: "نمط غير صالح"}"; result = ""
            }
        })
        Spacer(Modifier.height(8.dp))
        DangerButton("مسح", onClick = { pattern = ""; test = ""; result = ""; message = "" })
        if (message.isNotBlank()) {
            Spacer(Modifier.height(8.dp))
            Text(message, style = MaterialTheme.typography.labelLarge)
        }
        if (result.isNotBlank()) {
            Spacer(Modifier.height(12.dp))
            SectionLabel("المطابقات")
            OutputCard(result, minHeight = 60)
        }
    }
}

@Composable
private fun ToggleChip(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, style = MaterialTheme.typography.labelLarge)
        Spacer(Modifier.width(4.dp))
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}
