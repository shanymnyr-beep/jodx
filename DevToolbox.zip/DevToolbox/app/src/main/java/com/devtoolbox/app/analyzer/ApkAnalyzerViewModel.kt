package com.devtoolbox.app.analyzer

import android.content.Context
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class ApkAnalyzerViewModel : ViewModel() {
    var state by mutableStateOf(ScanUiState())
        private set

    private val mainHandler = Handler(Looper.getMainLooper())
    private val executor: ExecutorService = Executors.newSingleThreadExecutor { r ->
        Thread(r, "apk-analyzer-worker").apply { priority = Thread.NORM_PRIORITY }
    }
    private val stopping = AtomicBoolean(false)
    private val pendingMatches = ArrayList<MethodMatch>()
    private var flushPosted = false
    private var currentTempDir: File? = null

    fun selectApk(context: Context, uri: android.net.Uri) {
        executor.execute {
            try {
                val name = resolveApkName(context, uri)
                postState { copy(selectedName = name, selectedPath = uri.toString(), message = "تم اختيار التطبيق") }
            } catch (t: Throwable) {
                postState { copy(error = "تعذر قراءة التطبيق: ${t.message ?: "ملف غير صالح"}") }
            }
        }
    }

    fun start(context: Context) {
        val path = state.selectedPath ?: return
        if (state.scanning) return
        stopping.set(false)
        NativeDexScanner.reset()
        clearPending()
        postState {
            copy(
                scanning = true,
                ready = false,
                progress = 0f,
                processedClasses = 0,
                totalClasses = 0,
                currentClass = "",
                dexIndex = 0,
                dexTotal = 0,
                matches = emptyList(),
                message = "تحضير الفحص…",
                warning = null,
                error = null,
                elapsedMs = 0L
            )
        }
        executor.execute { runScan(context, path) }
    }

    fun stop() {
        if (!state.scanning) return
        stopping.set(true)
        NativeDexScanner.stop()
        postState { copy(message = "إيقاف الفحص…") }
    }

    private fun runScan(context: Context, uriString: String) {
        val startMs = System.currentTimeMillis()
        var tempDir: File? = null
        try {
            tempDir = File.createTempFile("apk_scan_", "", context.cacheDir).apply {
                delete()
                mkdirs()
            }
            currentTempDir = tempDir
            val uri = android.net.Uri.parse(uriString)
            val dexFiles = extractDexFiles(context, uri, tempDir)
            if (dexFiles.isEmpty()) throw IllegalArgumentException("لم يتم العثور على أي classes*.dex")
            val keywordsPath = copyKeywords(context)

            data class DexTarget(val file: File, val classes: Int)
            val targets = ArrayList<DexTarget>(dexFiles.size)
            var totalClasses = 0L
            for (dex in dexFiles) {
                if (stopping.get()) return finishCancelled(startMs)
                val count = NativeDexScanner.countClasses(dex.absolutePath)
                if (count < 0) throw IOException("DEX غير صالح: ${dex.name}")
                targets += DexTarget(dex, count)
                totalClasses += count.toLong()
            }
            if (totalClasses > Int.MAX_VALUE) throw IOException("عدد الكلاسات أكبر من الحد المدعوم")

            postState {
                copy(
                    totalClasses = totalClasses.toInt(),
                    dexTotal = dexFiles.size,
                    message = "Scanning…",
                    error = null
                )
            }

            var completedBefore = 0
            var warning = false
            for ((index, target) in targets.withIndex()) {
                if (stopping.get()) return finishCancelled(startMs)
                val dex = target.file
                postState { copy(dexIndex = index + 1, dexTotal = targets.size, message = "فحص ${dex.name}…") }
                val result = NativeDexScanner.scanDex(
                    dex.absolutePath,
                    dex.name,
                    keywordsPath.absolutePath,
                    listener(completedBefore, totalClasses.toInt(), startMs)
                )
                if (result < 0) throw IOException("تعذر تحليل ${dex.name} (code=$result)")
                if (result > 1) warning = true
                completedBefore += target.classes
                if (stopping.get()) return finishCancelled(startMs)
            }
            flushPendingNow()
            val elapsed = System.currentTimeMillis() - startMs
            postState {
                copy(
                    scanning = false,
                    ready = true,
                    progress = 1f,
                    processedClasses = totalClasses.toInt(),
                    currentClass = "",
                    message = "اكتمل الفحص",
                    warning = if (warning) "اكتمل الفحص مع تجاوز بعض البنى غير الصالحة." else null,
                    elapsedMs = elapsed
                )
            }
        } catch (t: Throwable) {
            flushPendingNow()
            postState {
                copy(
                    scanning = false,
                    ready = true,
                    message = "تعذر إكمال الفحص",
                    error = t.message ?: "خطأ غير معروف",
                    elapsedMs = System.currentTimeMillis() - startMs
                )
            }
        } finally {
            flushPendingNow()
            tempDir?.deleteRecursively()
            currentTempDir = null
            stopping.set(false)
        }
    }

    private fun finishCancelled(startMs: Long) {
        flushPendingNow()
        postState {
            copy(
                scanning = false,
                ready = true,
                message = "توقف الفحص — النتائج الحالية فقط",
                elapsedMs = System.currentTimeMillis() - startMs
            )
        }
    }

    private fun listener(base: Int, globalTotal: Int, scanStartMs: Long) = object : NativeDexScanner.Listener {
        override fun onProgress(processed: Int, total: Int, className: String) {
            val globalProcessed = (base + processed).coerceAtMost(globalTotal)
            val progress = if (globalTotal == 0) 1f else globalProcessed.toFloat() / globalTotal.toFloat()
            postState {
                copy(
                    processedClasses = globalProcessed,
                    totalClasses = globalTotal,
                    progress = progress.coerceIn(0f, 1f),
                    currentClass = className,
                    message = "Scanning…",
                    elapsedMs = System.currentTimeMillis() - scanStartMs
                )
            }
        }

        override fun onMatch(encoded: String) {
            parseMatch(encoded)?.let {
                synchronized(pendingMatches) { pendingMatches.add(it) }
                scheduleFlush()
            }
        }
    }

    private fun scheduleFlush() {
        synchronized(pendingMatches) {
            if (flushPosted) return
            flushPosted = true
        }
        mainHandler.postDelayed({ flushPendingNow() }, 90L)
    }

    private fun flushPendingNow() {
        val toAdd: List<MethodMatch> = synchronized(pendingMatches) {
            if (pendingMatches.isEmpty()) {
                flushPosted = false
                return
            }
            val copy = pendingMatches.toList()
            pendingMatches.clear()
            flushPosted = false
            copy
        }
        if (toAdd.isNotEmpty()) {
            postState {
                val merged = ArrayList<MethodMatch>(matches.size + toAdd.size)
                merged.addAll(matches)
                merged.addAll(toAdd)
                copy(matches = dedupe(merged))
            }
        }
    }

    private fun clearPending() {
        synchronized(pendingMatches) {
            pendingMatches.clear()
            flushPosted = false
        }
    }

    private fun postState(transform: ScanUiState.() -> ScanUiState) {
        mainHandler.post { state = transform(state) }
    }

    private fun parseMatch(encoded: String): MethodMatch? {
        val parts = encoded.split('\u001F')
        if (parts.size < 9) return null
        return try {
            MethodMatch(
                matchedKeywords = parts[0].split(',').filter { it.isNotBlank() },
                className = parts[1],
                methodName = parts[2],
                signature = parts[3],
                returnType = parts[4],
                dexName = parts[5],
                methodIndex = parts[6].toLong(),
                accessFlags = parts[7],
                kind = parts[8],
                codeOffset = parts.getOrNull(9)?.toLongOrNull() ?: 0L
            )
        } catch (_: Throwable) { null }
    }

    private fun dedupe(items: List<MethodMatch>): List<MethodMatch> {
        val seen = HashSet<String>(items.size)
        val out = ArrayList<MethodMatch>(items.size)
        for (item in items) {
            val key = item.dexName + "|" + item.signature
            if (seen.add(key)) out.add(item)
        }
        return out
    }

    private fun resolveApkName(context: Context, uri: android.net.Uri): String {
        val projection = arrayOf(android.provider.OpenableColumns.DISPLAY_NAME)
        context.contentResolver.query(uri, projection, null, null, null)?.use { cursor ->
            val index = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
            if (index >= 0 && cursor.moveToFirst()) {
                val name = cursor.getString(index)?.trim()
                if (!name.isNullOrEmpty()) return name
            }
        }
        return uri.lastPathSegment?.substringAfterLast('/')?.ifBlank { "Selected APK" } ?: "Selected APK"
    }

    private fun extractDexFiles(context: Context, uri: android.net.Uri, dir: File): List<File> {
        val out = ArrayList<File>()
        context.contentResolver.openInputStream(uri)?.use { input ->
            java.util.zip.ZipInputStream(input.buffered(64 * 1024)).use { zip ->
                while (true) {
                    val entry = zip.nextEntry ?: break
                    if (!entry.isDirectory && entry.name.matches(Regex("classes(?:[2-9][0-9]*)?\\.dex"))) {
                        val safeName = entry.name.substringAfterLast('/').replace(Regex("[^A-Za-z0-9_.-]"), "_")
                        val dst = File(dir, safeName)
                        FileOutputStream(dst).use { output -> zip.copyTo(output, 64 * 1024) }
                        out.add(dst)
                    }
                    zip.closeEntry()
                }
            }
        } ?: throw IOException("تعذر فتح APK")
        return out.sortedWith(Comparator { a, b ->
            fun order(name: String): Int = if (name == "classes.dex") 1 else {
                Regex("classes(\\d+)\\.dex").matchEntire(name)?.groupValues?.get(1)?.toIntOrNull()?.plus(0) ?: Int.MAX_VALUE
            }
            order(a.name).compareTo(order(b.name))
        })
    }

    private fun copyKeywords(context: Context): File {
        val target = File(context.cacheDir, "keywords.dat")
        context.assets.open("keywords.dat").use { input -> FileOutputStream(target).use { output -> input.copyTo(output, 16 * 1024) } }
        return target
    }

    override fun onCleared() {
        stopping.set(true)
        NativeDexScanner.stop()
        executor.shutdownNow()
        mainHandler.removeCallbacksAndMessages(null)
        currentTempDir?.deleteRecursively()
        super.onCleared()
    }
}
