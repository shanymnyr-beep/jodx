package com.devtoolbox.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.devtoolbox.app.ui.components.DangerButton
import com.devtoolbox.app.ui.components.OutputCard
import com.devtoolbox.app.ui.components.PrimaryButton
import com.devtoolbox.app.ui.components.SectionLabel
import com.devtoolbox.app.ui.components.ToolScaffold
import java.util.UUID

@Composable
fun UuidGeneratorScreen(onBack: () -> Unit) {
    var count by remember { mutableStateOf("1") }
    var upper by remember { mutableStateOf(false) }
    var braces by remember { mutableStateOf(false) }
    var noDashes by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf("") }

    ToolScaffold(title = "مولّد UUID", onBack = onBack) { mod ->
        SectionLabel("العدد")
        OutlinedTextField(
            value = count,
            onValueChange = { count = it.filter { c -> c.isDigit() }.take(3) },
            label = { Text("عدد المعرّفات (1 - 500)") },
            singleLine = true,
            modifier = mod
        )
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            ToggleChip("أحرف كبيرة", upper) { upper = it }
            ToggleChip("أقواس {}", braces) { braces = it }
            ToggleChip("بدون فواصل", noDashes) { noDashes = it }
        }
        Spacer(Modifier.height(10.dp))
        PrimaryButton("توليد", onClick = {
            val n = count.toIntOrNull()?.coerceIn(1, 500) ?: 1
            result = (1..n).joinToString("\n") {
                var u = UUID.randomUUID().toString()
                if (noDashes) u = u.replace("-", "")
                if (upper) u = u.uppercase()
                if (braces) u = "{$u}"
                u
            }
        })
        Spacer(Modifier.height(8.dp))
        DangerButton("مسح", onClick = { result = ""; count = "1" })
        if (result.isNotBlank()) {
            Spacer(Modifier.height(12.dp))
            SectionLabel("النتيجة")
            OutputCard(result, minHeight = 60)
        }
    }
}

@Composable
private fun ToggleChip(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, style = MaterialTheme.typography.labelLarge)
        Spacer(Modifier.width(4.dp))
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}
