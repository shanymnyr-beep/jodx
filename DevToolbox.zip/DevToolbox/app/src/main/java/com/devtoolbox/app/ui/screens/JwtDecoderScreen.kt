package com.devtoolbox.app.ui.screens

import android.util.Base64
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.devtoolbox.app.ui.components.DangerButton
import com.devtoolbox.app.ui.components.MultiLineField
import com.devtoolbox.app.ui.components.OutputCard
import com.devtoolbox.app.ui.components.PrimaryButton
import com.devtoolbox.app.ui.components.SectionLabel
import com.devtoolbox.app.ui.components.ToolScaffold
import org.json.JSONObject
import java.util.Date

@Composable
fun JwtDecoderScreen(onBack: () -> Unit) {
    var token by remember { mutableStateOf("") }
    var header by remember { mutableStateOf("") }
    var payload by remember { mutableStateOf("") }
    var info by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }

    ToolScaffold(title = "فاك JWT", onBack = onBack) { mod ->
        SectionLabel("الرمز (Token)")
        MultiLineField(token, { token = it }, "ألصق رمز JWT هنا", minHeight = 120)
        Spacer(Modifier.height(10.dp))
        PrimaryButton("فك التشفير", onClick = {
            runCatching {
                val parts = token.trim().split(".")
                require(parts.size == 3) { "يجب أن يحتوي JWT على 3 أجزاء مفصولة بنقطة" }
                val h = decodePart(parts[0])
                val p = decodePart(parts[1])
                header = prettyJson(h)
                payload = prettyJson(p)
                info = buildInfo(p)
                message = "✓ تم فك التشفير"
            }.onFailure {
                header = ""; payload = ""; info = ""
                message = "✗ ${it.message ?: "رمز غير صالح"}"
            }
        })
        Spacer(Modifier.height(8.dp))
        DangerButton("مسح", onClick = {
            token = ""; header = ""; payload = ""; info = ""; message = ""
        })
        if (message.isNotBlank()) {
            Spacer(Modifier.height(8.dp))
            Text(message, style = MaterialTheme.typography.labelLarge)
        }
        if (header.isNotBlank()) {
            Spacer(Modifier.height(12.dp))
            SectionLabel("Header")
            OutputCard(header, minHeight = 40)
        }
        if (payload.isNotBlank()) {
            Spacer(Modifier.height(12.dp))
            SectionLabel("Payload")
            OutputCard(payload, minHeight = 40)
        }
        if (info.isNotBlank()) {
            Spacer(Modifier.height(12.dp))
            SectionLabel("معلومات الصلاحية")
            OutputCard(info, mono = false, minHeight = 40)
        }
    }
}

private fun decodePart(part: String): String {
    var s = part.replace("-", "+").replace("_", "/")
    // pad to multiple of 4
    val rem = s.length % 4
    if (rem == 2) s += "==" else if (rem == 3) s += "="
    return String(Base64.decode(s, Base64.NO_WRAP), Charsets.UTF_8)
}

private fun prettyJson(raw: String): String =
    JSONObject(raw).toString(2)

private fun buildInfo(payloadJson: String): String {
    val obj = JSONObject(payloadJson)
    val sb = StringBuilder()
    val now = System.currentTimeMillis() / 1000
    if (obj.has("iss")) sb.append("المُصدِر (iss): ${obj.getString("iss")}\n")
    if (obj.has("sub")) sb.append("الموضوع (sub): ${obj.get("sub")}\n")
    if (obj.has("iat")) sb.append("أُصدر في (iat): ${obj.get("iat")}\n")
    if (obj.has("exp")) {
        val exp = obj.getLong("exp")
        val expDate = Date(exp * 1000).toString()
        sb.append("ينتهي في (exp): $expDate\n")
        sb.append(if (exp < now) "الحالة: ✗ منتهي الصلاحية" else "الحالة: ✓ ساري")
    } else {
        sb.append("الحالة: لا يوجد حقل انتهاء (exp)")
    }
    return sb.toString().trimEnd('\n')
}
