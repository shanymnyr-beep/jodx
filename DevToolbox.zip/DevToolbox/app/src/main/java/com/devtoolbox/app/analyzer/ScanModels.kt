package com.devtoolbox.app.analyzer

data class MethodMatch(
    val matchedKeywords: List<String>,
    val className: String,
    val methodName: String,
    val signature: String,
    val returnType: String,
    val dexName: String,
    val methodIndex: Long,
    val accessFlags: String,
    val kind: String,
    val codeOffset: Long
)

data class ScanUiState(
    val selectedName: String? = null,
    val selectedPath: String? = null,
    val ready: Boolean = true,
    val scanning: Boolean = false,
    val progress: Float = 0f,
    val processedClasses: Int = 0,
    val totalClasses: Int = 0,
    val currentClass: String = "",
    val dexIndex: Int = 0,
    val dexTotal: Int = 0,
    val matches: List<MethodMatch> = emptyList(),
    val message: String = "جاهز",
    val warning: String? = null,
    val error: String? = null,
    val elapsedMs: Long = 0L
) {
    val remainingClasses: Int
        get() = (totalClasses - processedClasses).coerceAtLeast(0)

    val rate: Double
        get() = if (elapsedMs <= 0L) 0.0 else processedClasses * 1000.0 / elapsedMs

    val estimatedRemainingSeconds: Long
        get() = if (rate <= 0.0) 0L else (remainingClasses / rate).toLong()
}
