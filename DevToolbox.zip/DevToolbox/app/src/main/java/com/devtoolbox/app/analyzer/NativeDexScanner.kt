package com.devtoolbox.app.analyzer

object NativeDexScanner {
    init {
        System.loadLibrary("dexscanner")
    }

    interface Listener {
        fun onProgress(processed: Int, total: Int, className: String)
        fun onMatch(encoded: String)
    }

    external fun countClasses(dexPath: String): Int
    external fun scanDex(
        dexPath: String,
        dexName: String,
        keywordsPath: String,
        listener: Listener
    ): Int

    external fun stop()
    external fun reset()
}
