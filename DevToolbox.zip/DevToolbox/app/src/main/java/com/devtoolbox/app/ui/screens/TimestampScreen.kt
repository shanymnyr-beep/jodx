package com.devtoolbox.app.ui.screens

import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import com.devtoolbox.app.ui.components.DangerButton
import com.devtoolbox.app.ui.components.OutputCard
import com.devtoolbox.app.ui.components.PrimaryButton
import com.devtoolbox.app.ui.components.SecondaryButton
import com.devtoolbox.app.ui.components.SectionLabel
import com.devtoolbox.app.ui.components.ToolScaffold
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

@Composable
fun TimestampScreen(onBack: () -> Unit) {
    var input by remember { mutableStateOf("") }
    var output by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }

    ToolScaffold(title = "محوّل الطابع الزمني", onBack = onBack) { mod ->
        SectionLabel("الطابع الزمني (Unix)")
        OutlinedTextField(
            value = input,
            onValueChange = { input = it.filter { c -> c.isDigit() || c == '-' }.take(13) },
            label = { Text("بالثواني أو المللي ثانية") },
            singleLine = true,
            textStyle = MaterialTheme.typography.bodyMedium.copy(fontFamily = FontFamily.Monospace),
            modifier = mod
        )
        Spacer(Modifier.height(10.dp))
        androidx.compose.foundation.layout.Row(horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp)) {
            PrimaryButton("حوّل", modifier = Modifier, onClick = {
                if (input.isBlank()) { output = ""; message = "✗ أدخل قيمة"; return@PrimaryButton }
                runCatching {
                    val n = input.toLong()
                    val millis = if (input.length <= 10) n * 1000 else n
                    val date = Date(millis)
                    val utc = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }
                    val local = SimpleDateFormat("yyyy-MM-dd HH:mm:ss z", Locale.getDefault())
                    buildString {
                        appendLine("UTC:      ${utc.format(date)}")
                        appendLine("محلي:    ${local.format(date)}")
                        appendLine("ISO 8601: ${SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }.format(date)}")
                        append("Unix (s): ${millis / 1000}")
                    }.also { output = it; message = "✓ تم التحويل" }
                }.onFailure { output = ""; message = "✗ قيمة غير صالحة" }
            })
            SecondaryButton("الوقت الحالي", onClick = {
                input = (System.currentTimeMillis() / 1000).toString()
            })
        }
        Spacer(Modifier.height(8.dp))
        DangerButton("مسح", onClick = { input = ""; output = ""; message = "" })
        if (message.isNotBlank()) {
            Spacer(Modifier.height(8.dp))
            Text(message, style = MaterialTheme.typography.labelLarge)
        }
        if (output.isNotBlank()) {
            Spacer(Modifier.height(12.dp))
            SectionLabel("التاريخ")
            OutputCard(output, mono = true, minHeight = 90)
        }
    }
}
