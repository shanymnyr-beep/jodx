package com.devtoolbox.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import com.devtoolbox.app.ui.components.OutputCard
import com.devtoolbox.app.ui.components.SectionLabel
import com.devtoolbox.app.ui.components.ToolScaffold
import kotlin.math.max
import kotlin.math.min

@Composable
fun ColorToolScreen(onBack: () -> Unit) {
    var hex by remember { mutableStateOf("0E7C86") }
    var color by remember { mutableStateOf(parseHex("0E7C86")) }
    var message by remember { mutableStateOf("") }

    LaunchedEffect(hex) {
        val parsed = parseHex(hex)
        if (parsed != null) {
            color = parsed
            message = ""
        } else {
            message = "✗ صيغة غير صالحة (مثال: 0E7C86 أو #0E7C86)"
        }
    }

    ToolScaffold(title = "أداة الألوان", onBack = onBack) { mod ->
        SectionLabel("اللون (Hex)")
        OutlinedTextField(
            value = hex,
            onValueChange = { hex = it.replace(Regex("[^0-9A-Fa-f#]"), "").take(7) },
            label = { Text("#RRGGBB") },
            singleLine = true,
            textStyle = MaterialTheme.typography.bodyMedium.copy(fontFamily = FontFamily.Monospace),
            modifier = mod
        )
        if (message.isNotBlank()) {
            Spacer(Modifier.height(6.dp))
            Text(message, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.error)
        }
        Spacer(Modifier.height(12.dp))
        if (color != null) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(90.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(color!!)
            )
            Spacer(Modifier.height(12.dp))
            val r = (color!!.red * 255).toInt()
            val g = (color!!.green * 255).toInt()
            val b = (color!!.blue * 255).toInt()
            val hsl = rgbToHsl(r, g, b)
            val results = buildString {
                appendLine("Hex: #${hex.replace("#", "").uppercase()}")
                appendLine("RGB: rgb($r, $g, $b)")
                appendLine("HSL: hsl(${hsl.first.toInt()}, ${hsl.second}%, ${hsl.third}%)")
                appendLine("Float: ${"%.3f".format(color!!.red)}, ${"%.3f".format(color!!.green)}, ${"%.3f".format(color!!.blue)}")
            }.trimEnd('\n')
            SectionLabel("القيم")
            OutputCard(results, minHeight = 60)
        }
    }
}

private fun parseHex(input: String): Color? {
    val clean = input.removePrefix("#").trim()
    return try {
        when (clean.length) {
            6 -> {
                val v = clean.toLong(16)
                Color(
                    red = ((v shr 16) and 0xFF) / 255f,
                    green = ((v shr 8) and 0xFF) / 255f,
                    blue = (v and 0xFF) / 255f,
                    alpha = 1f
                )
            }
            8 -> {
                val v = clean.toLong(16)
                Color(
                    alpha = ((v shr 24) and 0xFF) / 255f,
                    red = ((v shr 16) and 0xFF) / 255f,
                    green = ((v shr 8) and 0xFF) / 255f,
                    blue = (v and 0xFF) / 255f
                )
            }
            else -> null
        }
    } catch (e: Exception) {
        null
    }
}

private fun rgbToHsl(r: Int, g: Int, b: Int): Triple<Float, Int, Int> {
    val rr = r / 255f
    val gg = g / 255f
    val bb = b / 255f
    val maxVal = max(rr, max(gg, bb))
    val minVal = min(rr, min(gg, bb))
    val delta = maxVal - minVal
    val l = (maxVal + minVal) / 2f
    var h: Float
    var s: Float
    if (delta == 0f) {
        h = 0f
        s = 0f
    } else {
        s = if (l < 0.5f) delta / (maxVal + minVal) else delta / (2f - maxVal - minVal)
        h = when (maxVal) {
            rr -> ((gg - bb) / delta) % 6f
            gg -> (bb - rr) / delta + 2f
            else -> (rr - gg) / delta + 4f
        }
        if (h < 0f) h += 6f
    }
    return Triple(h * 60f, (s * 100).toInt(), (l * 100).toInt())
}
