package com.devtoolbox.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.devtoolbox.app.ui.components.DangerButton
import com.devtoolbox.app.ui.components.OutputCard
import com.devtoolbox.app.ui.components.PrimaryButton
import com.devtoolbox.app.ui.components.SectionLabel
import com.devtoolbox.app.ui.components.ToolScaffold
import java.security.SecureRandom
import kotlin.math.log2

@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun PasswordGeneratorScreen(onBack: () -> Unit) {
    var length by remember { mutableStateOf(16f) }
    var upper by remember { mutableStateOf(true) }
    var lower by remember { mutableStateOf(true) }
    var digits by remember { mutableStateOf(true) }
    var symbols by remember { mutableStateOf(true) }
    var result by remember { mutableStateOf("") }

    val pool = buildString {
        if (upper) append("ABCDEFGHIJKLMNOPQRSTUVWXYZ")
        if (lower) append("abcdefghijklmnopqrstuvwxyz")
        if (digits) append("0123456789")
        if (symbols) append("!@#\$%^&*()-_=+[]{};:,.?/")
    }
    val strength = passwordStrength(result, pool.length)

    ToolScaffold(title = "مولّد كلمات المرور", onBack = onBack) { mod ->
        SectionLabel("الطول: ${length.toInt()}")
        Slider(
            value = length,
            onValueChange = { length = it },
            valueRange = 4f..48f,
            steps = 43
        )
        Spacer(Modifier.height(10.dp))
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ToggleChip("أحرف كبيرة", upper) { upper = it }
            ToggleChip("أحرف صغيرة", lower) { lower = it }
            ToggleChip("أرقام", digits) { digits = it }
            ToggleChip("رموز", symbols) { symbols = it }
        }
        Spacer(Modifier.height(12.dp))
        PrimaryButton("توليد", onClick = {
            val p = pool.toString()
            if (p.isEmpty()) { result = "اختر فئة واحدة على الأقل"; return@PrimaryButton }
            val n = length.toInt()
            val random = SecureRandom()
            result = (1..n).map { p[random.nextInt(p.length)] }.joinToString("")
        })
        Spacer(Modifier.height(8.dp))
        DangerButton("مسح", onClick = { result = "" })
        if (result.isNotBlank()) {
            Spacer(Modifier.height(12.dp))
            SectionLabel("القوة")
            LinearProgressIndicator(
                progress = { strength / 100f },
                modifier = Modifier.fillMaxWidth().height(8.dp),
                color = when {
                    strength < 40 -> MaterialTheme.colorScheme.error
                    strength < 70 -> MaterialTheme.colorScheme.tertiary
                    else -> MaterialTheme.colorScheme.primary
                }
            )
            Spacer(Modifier.height(6.dp))
            Text(strengthLabel(strength), style = MaterialTheme.typography.labelLarge)
            Spacer(Modifier.height(8.dp))
            SectionLabel("كلمة المرور")
            OutputCard(result, minHeight = 40)
        }
    }
}

@Composable
private fun ToggleChip(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, style = MaterialTheme.typography.labelLarge)
        Spacer(Modifier.width(4.dp))
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

private fun passwordStrength(pwd: String, poolSize: Int): Int {
    if (pwd.isBlank() || poolSize == 0) return 0
    val entropy = pwd.length * log2(poolSize.toDouble())
    return (entropy.coerceIn(0.0, 128.0) / 128.0 * 100).toInt()
}

private fun strengthLabel(s: Int) = when {
    s < 40 -> "ضعيفة ✗"
    s < 70 -> "متوسطة △"
    else -> "قوية ✓"
}
