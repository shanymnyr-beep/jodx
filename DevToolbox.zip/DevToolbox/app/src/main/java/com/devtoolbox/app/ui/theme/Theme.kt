package com.devtoolbox.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val LightColors = lightColorScheme(
    primary = ColorPurple,
    onPrimary = ColorWhite,
    primaryContainer = ColorPurpleDark,
    onPrimaryContainer = ColorWhite,
    background = ColorLightBg,
    onBackground = ColorDarkText,
    surface = ColorLightBg,
    onSurface = ColorDarkText,
    surfaceVariant = ColorLightSurface,
    onSurfaceVariant = ColorDarkMuted,
    outline = ColorLightOutline
)

private val DarkColors = darkColorScheme(
    primary = ColorPurpleBright,
    onPrimary = ColorDarkBg,
    primaryContainer = ColorPurpleDark,
    onPrimaryContainer = ColorWhite,
    background = ColorDarkBg,
    onBackground = ColorWhite,
    surface = ColorDarkBg,
    onSurface = ColorWhite,
    surfaceVariant = ColorDarkCard,
    onSurfaceVariant = ColorDarkMuted,
    outline = ColorDarkOutline
)

@Composable
fun DevToolboxTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = AppTypography,
        content = content
    )
}
