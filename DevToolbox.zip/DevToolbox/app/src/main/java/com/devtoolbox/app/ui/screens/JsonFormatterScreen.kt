package com.devtoolbox.app.ui.screens

import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.devtoolbox.app.ui.components.ActionRow
import com.devtoolbox.app.ui.components.DangerButton
import com.devtoolbox.app.ui.components.MultiLineField
import com.devtoolbox.app.ui.components.OutputCard
import com.devtoolbox.app.ui.components.PrimaryButton
import com.devtoolbox.app.ui.components.SecondaryButton
import com.devtoolbox.app.ui.components.SectionLabel
import com.devtoolbox.app.ui.components.ToolScaffold
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener

@Composable
fun JsonFormatterScreen(onBack: () -> Unit) {
    var input by remember { mutableStateOf("") }
    var output by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }

    ToolScaffold(title = "منسّق JSON", onBack = onBack) { mod ->
        SectionLabel("الإدخال")
        MultiLineField(
            value = input,
            onValueChange = { input = it },
            label = "ألصق JSON هنا",
            minHeight = 140
        )
        Spacer(Modifier.height(10.dp))
        ActionRow(
            {
                PrimaryButton("تنسيق", onClick = {
                    processJson(input, 2,
                        onSuccess = { output = it; message = "✓ تم التنسيق بنجاح" },
                        onError = { output = ""; message = "✗ ${it.message ?: "خطأ"}" }
                    )
                })
            },
            {
                SecondaryButton("ضغط", onClick = {
                    processJson(input, 0,
                        onSuccess = { output = it; message = "✓ تم الضغط" },
                        onError = { output = ""; message = "✗ ${it.message ?: "خطأ"}" }
                    )
                })
            }
        )
        Spacer(Modifier.height(8.dp))
        ActionRow(
            {
                SecondaryButton("تحقق", onClick = {
                    processJson(input, 0,
                        onSuccess = { message = "✓ JSON صحيح"; output = if (input.isBlank()) "" else it },
                        onError = { message = "✗ ${it.message ?: "خطأ"}" }
                    )
                })
            },
            {
                DangerButton("مسح", onClick = { input = ""; output = ""; message = "" })
            }
        )
        if (message.isNotBlank()) {
            Spacer(Modifier.height(8.dp))
            Text(message, style = MaterialTheme.typography.labelLarge)
        }
        if (output.isNotBlank()) {
            Spacer(Modifier.height(12.dp))
            SectionLabel("النتيجة")
            OutputCard(output)
        }
    }
}

private fun processJson(
    input: String,
    indent: Int,
    onSuccess: (String) -> Unit,
    onError: (Throwable) -> Unit
) {
    if (input.isBlank()) {
        onError(IllegalArgumentException("الإدخال فارغ"))
        return
    }
    runCatching {
        val value = JSONTokener(input.trim()).nextValue()
            ?: throw IllegalArgumentException("ليس JSON صالحاً")
        when (value) {
            is JSONObject -> value.toString(indent)
            is JSONArray -> value.toString(indent)
            else -> value.toString()
        }
    }.onSuccess(onSuccess).onFailure(onError)
}
