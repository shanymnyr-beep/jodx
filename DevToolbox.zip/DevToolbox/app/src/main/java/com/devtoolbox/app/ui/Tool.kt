package com.devtoolbox.app.ui

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.DataObject
import androidx.compose.material.icons.filled.EnhancedEncryption
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Password
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Search
import androidx.compose.ui.graphics.vector.ImageVector

enum class Tool(
    val titleAr: String,
    val titleEn: String,
    val description: String,
    val icon: ImageVector,
    val route: String
) {
    ApkAnalyzer(
        "فاحص APK المتقدم", "APK Method & Purchase Analyzer",
        "فحص عميق وسريع لكل DEX والدوال المطابقة لكلمات VIP وPremium وPro والشراء والاشتراكات",
        Icons.Filled.Search, "tool_apk_analyzer"
    ),
    JsonFormatter(
        "منسّق JSON", "JSON Formatter",
        "تنسيق وضغط والتحقق من صحة JSON",
        Icons.Filled.DataObject, "tool_json"
    ),
    Base64(
        "Base64", "Base64",
        "ترميز وفك ترميز Base64",
        Icons.Filled.Code, "tool_base64"
    ),
    UrlEncoder(
        "ترميز URL", "URL Encoder",
        "ترميز (Encode) وفك ترميز (Decode) عناوين URL",
        Icons.Filled.Link, "tool_url"
    ),
    RegexTester(
        "اختبار Regex", "Regex Tester",
        "اختبار التعابير المنطقية وإظهار المطابقات",
        Icons.Filled.Search, "tool_regex"
    ),
    JwtDecoder(
        "فاك JWT", "JWT Decoder",
        "فك ترميز وفحص حقول رمز JWT",
        Icons.Filled.Key, "tool_jwt"
    ),
    UuidGenerator(
        "مولّد UUID", "UUID Generator",
        "توليد معرفات UUID v4 بشكل فردي أو دفعي",
        Icons.Filled.Fingerprint, "tool_uuid"
    ),
    HashGenerator(
        "مولّد الهاش", "Hash Generator",
        "حساب MD5 و SHA-1 و SHA-256 و SHA-512",
        Icons.Filled.EnhancedEncryption, "tool_hash"
    ),
    ColorTool(
        "أداة الألوان", "Color Tool",
        "تحويل بين Hex و RGB و HSL مع معاينة",
        Icons.Filled.Palette, "tool_color"
    ),
    PasswordGenerator(
        "مولّد كلمات المرور", "Password Generator",
        "توليد كلمات مرور قوية وموثوقة",
        Icons.Filled.Password, "tool_password"
    ),
    NumberBase(
        "محوّل الأنظمة", "Base Converter",
        "تحويل بين الثنائي والعشري والسداسي عشر والثماني",
        Icons.Filled.Calculate, "tool_base"
    ),
    Timestamp(
        "محوّل الطابع الزمني", "Timestamp",
        "تحويل بين Unix timestamp والتاريخ المقروء",
        Icons.Filled.Schedule, "tool_timestamp"
    );

    companion object {
        val ArrowBack = Icons.AutoMirrored.Filled.ArrowBack
    }
}
