package com.devtoolbox.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import com.devtoolbox.app.ui.components.DangerButton
import com.devtoolbox.app.ui.components.OutputCard
import com.devtoolbox.app.ui.components.PrimaryButton
import com.devtoolbox.app.ui.components.SectionLabel
import com.devtoolbox.app.ui.components.ToolScaffold
import java.math.BigInteger

private data class BaseDef(val name: String, val radix: Int)

@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun NumberBaseScreen(onBack: () -> Unit) {
    val bases = listOf(
        BaseDef("ثنائي BIN", 2),
        BaseDef("ثماني OCT", 8),
        BaseDef("عشري DEC", 10),
        BaseDef("سداسي HEX", 16)
    )
    var input by remember { mutableStateOf("") }
    var fromRadix by remember { mutableStateOf(10) }
    var output by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }

    ToolScaffold(title = "محوّل الأنظمة", onBack = onBack) { mod ->
        SectionLabel("القيمة")
        OutlinedTextField(
            value = input,
            onValueChange = { input = it.uppercase().filter { it.isLetterOrDigit() } },
            label = { Text("أدخل الرقم") },
            singleLine = true,
            textStyle = MaterialTheme.typography.bodyMedium.copy(fontFamily = FontFamily.Monospace),
            modifier = mod
        )
        Spacer(Modifier.height(10.dp))
        SectionLabel("من النظام")
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            bases.forEach { b ->
                FilterChip(
                    selected = fromRadix == b.radix,
                    onClick = { fromRadix = b.radix },
                    label = { Text(b.name) }
                )
            }
        }
        Spacer(Modifier.height(10.dp))
        PrimaryButton("حوّل", onClick = {
            if (input.isBlank()) { output = ""; message = "✗ أدخل قيمة"; return@PrimaryButton }
            runCatching {
                val value = BigInteger(input.lowercase(), fromRadix)
                buildString {
                    appendLine("الثنائي (2):  ${value.toString(2)}")
                    appendLine("الثماني (8):  ${value.toString(8)}")
                    appendLine("العشري (10): ${value.toString(10)}")
                    append("السداسي (16): ${value.toString(16).uppercase()}")
                }.also {
                    output = it; message = "✓ تم التحويل"
                }
            }.onFailure {
                output = ""; message = "✗ القيمة غير صالحة لهذا النظام"
            }
        })
        Spacer(Modifier.height(8.dp))
        DangerButton("مسح", onClick = { input = ""; output = ""; message = "" })
        if (message.isNotBlank()) {
            Spacer(Modifier.height(8.dp))
            Text(message, style = MaterialTheme.typography.labelLarge)
        }
        if (output.isNotBlank()) {
            Spacer(Modifier.height(12.dp))
            SectionLabel("النتائج")
            OutputCard(output, minHeight = 90)
        }
    }
}
