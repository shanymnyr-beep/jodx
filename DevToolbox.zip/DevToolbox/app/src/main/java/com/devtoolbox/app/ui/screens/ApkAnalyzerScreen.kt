package com.devtoolbox.app.ui.screens

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.devtoolbox.app.analyzer.ApkAnalyzerViewModel
import com.devtoolbox.app.analyzer.MethodMatch
import com.devtoolbox.app.analyzer.ScanUiState
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun ApkAnalyzerScreen(onBack: () -> Unit, vm: ApkAnalyzerViewModel = viewModel()) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val snackbar = remember { SnackbarHostState() }
    var selectedMethod by remember { mutableStateOf<String?>(null) }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val path = uri.toString()
            if (!path.lowercase(Locale.ROOT).contains(".apk")) {
                Toast.makeText(context, "اختر ملف APK فقط", Toast.LENGTH_SHORT).show()
            } else {
                vm.selectApk(context, uri)
            }
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            TopAppBar(
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) } },
                title = { Text("APK Analyzer", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(
                    titleContentColor = MaterialTheme.colorScheme.onSurface,
                    navigationIconContentColor = MaterialTheme.colorScheme.onSurface
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("by : BLRX VIP", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
            Text(
                "فحص عميق Read-only لكل classes*.dex والدوال المطابقة لقائمة الكلمات المفتاحية الكاملة.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            OutlinedButton(
                onClick = { launcher.launch(arrayOf("application/vnd.android.package-archive", "application/octet-stream", "*/*")) },
                enabled = !vm.state.scanning,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(Icons.Filled.Search, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("اختيار تطبيق APK")
            }

            vm.state.selectedName?.let { name ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.72f))
                ) {
                    Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.CheckCircle, null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text("التطبيق المختار", style = MaterialTheme.typography.labelMedium)
                            Text(name, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
            }

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = { vm.start(context) },
                    enabled = vm.state.selectedPath != null && !vm.state.scanning,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Filled.Search, null)
                    Spacer(Modifier.width(6.dp))
                    Text("ابدأ")
                }
                OutlinedButton(
                    onClick = { vm.stop() },
                    enabled = vm.state.scanning,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Filled.Stop, null)
                    Spacer(Modifier.width(6.dp))
                    Text("وقف")
                }
            }

            ProgressPanel(vm.state)
            ResultPanel(vm.state) { selectedMethod = it }

            Spacer(Modifier.height(8.dp))
        }
    }

    val key = selectedMethod
    if (key != null) {
        val all = vm.state.matches.filter { it.methodName == key }.toList()
        MethodDetailsDialog(methodName = key, matches = all) { selectedMethod = null }
    }
}

@Composable
private fun ProgressPanel(state: ScanUiState) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.58f))
    ) {
        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(state.message, fontWeight = FontWeight.SemiBold)
                Text("${(state.progress * 100).toInt()}%", color = MaterialTheme.colorScheme.primary)
            }
            LinearProgressIndicator(
                progress = { state.progress.coerceIn(0f, 1f) },
                modifier = Modifier.fillMaxWidth()
            )
            if (state.totalClasses > 0) {
                Text(
                    "DEX ${state.dexIndex.coerceAtLeast(0)} / ${state.dexTotal}    •    ${state.processedClasses} / ${state.totalClasses}",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    "المتبقي: ${state.remainingClasses} class" + if (state.estimatedRemainingSeconds > 0) "  •  ≈ ${state.estimatedRemainingSeconds}s" else "",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (state.currentClass.isNotBlank()) {
                    Text(
                        "يبحث الآن: ${state.currentClass}",
                        style = MaterialTheme.typography.bodySmall,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
            Text("Matches: ${state.matches.size}", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
            state.error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            state.warning?.let { Text(it, color = MaterialTheme.colorScheme.tertiary) }
        }
    }
}

@Composable
private fun ResultPanel(state: ScanUiState, onMethodClick: (String) -> Unit) {
    val grouped = remember(state.matches) {
        state.matches.groupBy { it.methodName }
            .toList()
            .sortedWith(compareByDescending<Pair<String, List<MethodMatch>>> { it.second.size }.thenBy { it.first })
    }
    Card(
        modifier = Modifier.fillMaxWidth().height(360.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.95f))
    ) {
        Column(Modifier.fillMaxSize()) {
            Text("النتائج", modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp), fontWeight = FontWeight.Bold)
            HorizontalDivider()
            if (grouped.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("لا توجد نتائج مطابقة حتى الآن", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                LazyColumn(Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(8.dp)) {
                    items(grouped, key = { it.first }) { (name, entries) ->
                        ResultRow(name, entries.size, entries.first().matchedKeywords, onClick = { onMethodClick(name) })
                    }
                }
            }
        }
    }
}

@Composable
private fun ResultRow(name: String, count: Int, keywords: List<String>, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(name, fontWeight = FontWeight.SemiBold)
            Text(
                "Matched: ${keywords.joinToString(", ")}",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.primary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        Text("Found: $count", color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun MethodDetailsDialog(methodName: String, matches: List<MethodMatch>, onDismiss: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(methodName, fontWeight = FontWeight.Bold) },
        text = {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(matches) { m ->
                    Card(shape = RoundedCornerShape(14.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.62f))) {
                        Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            InfoLine("Matched", m.matchedKeywords.joinToString(", "))
                            InfoLine("Class", m.className)
                            InfoLine("Method", m.methodName)
                            InfoLine("Signature", m.signature)
                            InfoLine("Return", "${m.returnType} ${returnTypeName(m.returnType)}")
                            InfoLine("DEX", m.dexName)
                            InfoLine("Kind", m.kind)
                            InfoLine("Access", m.accessFlags)
                            InfoLine("Method index", m.methodIndex.toString())
                            InfoLine("Code offset", "0x${m.codeOffset.toString(16)}")
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(onClick = {
                                    val cm = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                                    cm.setPrimaryClip(android.content.ClipData.newPlainText("signature", m.signature))
                                    Toast.makeText(context, "Copied", Toast.LENGTH_SHORT).show()
                                }) {
                                    Icon(Icons.Filled.ContentCopy, null)
                                    Spacer(Modifier.width(5.dp))
                                    Text("نسخ signature")
                                }
                                OutlinedButton(onClick = {
                                    val cm = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                                    cm.setPrimaryClip(android.content.ClipData.newPlainText("method", m.methodName))
                                    Toast.makeText(context, "Copied", Toast.LENGTH_SHORT).show()
                                }) {
                                    Icon(Icons.Filled.ContentCopy, null)
                                    Spacer(Modifier.width(5.dp))
                                    Text("نسخ method")
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { Button(onClick = onDismiss) { Text("إغلاق") } }
    )
}

@Composable
private fun InfoLine(label: String, value: String) {
    Column {
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
        Text(value, style = MaterialTheme.typography.bodySmall)
    }
}

private fun returnTypeName(type: String): String = when (type) {
    "V" -> "void"
    "Z" -> "boolean"
    "B" -> "byte"
    "C" -> "char"
    "S" -> "short"
    "I" -> "int"
    "J" -> "long"
    "F" -> "float"
    "D" -> "double"
    else -> type.removePrefix("L").removeSuffix(";").replace('/', '.')
}
