package com.devtoolbox.app.ui.screens

import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.devtoolbox.app.ui.components.ActionRow
import com.devtoolbox.app.ui.components.DangerButton
import com.devtoolbox.app.ui.components.MultiLineField
import com.devtoolbox.app.ui.components.OutputCard
import com.devtoolbox.app.ui.components.PrimaryButton
import com.devtoolbox.app.ui.components.SecondaryButton
import com.devtoolbox.app.ui.components.SectionLabel
import com.devtoolbox.app.ui.components.ToolScaffold
import java.net.URLDecoder
import java.net.URLEncoder

@Composable
fun UrlEncoderScreen(onBack: () -> Unit) {
    var input by remember { mutableStateOf("") }
    var output by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }

    ToolScaffold(title = "ترميز URL", onBack = onBack) { mod ->
        SectionLabel("النص")
        MultiLineField(input, { input = it }, "أدخل النص", minHeight = 120)
        Spacer(Modifier.height(10.dp))
        ActionRow(
            {
                PrimaryButton("ترميز", onClick = {
                    runCatching { URLEncoder.encode(input, "UTF-8") }
                        .onSuccess { output = it; message = "✓ تم الترميز" }
                        .onFailure { output = ""; message = "✗ ${it.message ?: "خطأ"}" }
                })
            },
            {
                SecondaryButton("فك الترميز", onClick = {
                    runCatching { URLDecoder.decode(input, "UTF-8") }
                        .onSuccess { output = it; message = "✓ تم فك الترميز" }
                        .onFailure { output = ""; message = "✗ ترميز غير صالح" }
                })
            }
        )
        Spacer(Modifier.height(8.dp))
        DangerButton("مسح", onClick = { input = ""; output = ""; message = "" })
        if (message.isNotBlank()) {
            Spacer(Modifier.height(8.dp))
            Text(message, style = MaterialTheme.typography.labelLarge)
        }
        if (output.isNotBlank()) {
            Spacer(Modifier.height(12.dp))
            SectionLabel("النتيجة")
            OutputCard(output)
        }
    }
}
