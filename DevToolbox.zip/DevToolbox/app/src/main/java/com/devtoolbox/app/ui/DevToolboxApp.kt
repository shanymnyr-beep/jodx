package com.devtoolbox.app.ui

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.devtoolbox.app.ui.screens.ApkAnalyzerScreen
import com.devtoolbox.app.ui.screens.Base64Screen
import com.devtoolbox.app.ui.screens.ColorToolScreen
import com.devtoolbox.app.ui.screens.HashGeneratorScreen
import com.devtoolbox.app.ui.screens.JsonFormatterScreen
import com.devtoolbox.app.ui.screens.JwtDecoderScreen
import com.devtoolbox.app.ui.screens.NumberBaseScreen
import com.devtoolbox.app.ui.screens.PasswordGeneratorScreen
import com.devtoolbox.app.ui.screens.RegexTesterScreen
import com.devtoolbox.app.ui.screens.TimestampScreen
import com.devtoolbox.app.ui.screens.UrlEncoderScreen
import com.devtoolbox.app.ui.screens.UuidGeneratorScreen

private const val ROUTE_HOME = "home"

@Composable
fun DevToolboxApp() {
    val navController = rememberNavController()
    NavHost(navController = navController, startDestination = ROUTE_HOME) {
        composable(ROUTE_HOME) { HomeScreen(navController) }
        composable(Tool.ApkAnalyzer.route) {
            ApkAnalyzerScreen(onBack = { navController.popBackStack() })
        }
        composable(Tool.JsonFormatter.route) {
            JsonFormatterScreen(onBack = { navController.popBackStack() })
        }
        composable(Tool.Base64.route) {
            Base64Screen(onBack = { navController.popBackStack() })
        }
        composable(Tool.UrlEncoder.route) {
            UrlEncoderScreen(onBack = { navController.popBackStack() })
        }
        composable(Tool.RegexTester.route) {
            RegexTesterScreen(onBack = { navController.popBackStack() })
        }
        composable(Tool.JwtDecoder.route) {
            JwtDecoderScreen(onBack = { navController.popBackStack() })
        }
        composable(Tool.UuidGenerator.route) {
            UuidGeneratorScreen(onBack = { navController.popBackStack() })
        }
        composable(Tool.HashGenerator.route) {
            HashGeneratorScreen(onBack = { navController.popBackStack() })
        }
        composable(Tool.ColorTool.route) {
            ColorToolScreen(onBack = { navController.popBackStack() })
        }
        composable(Tool.PasswordGenerator.route) {
            PasswordGeneratorScreen(onBack = { navController.popBackStack() })
        }
        composable(Tool.NumberBase.route) {
            NumberBaseScreen(onBack = { navController.popBackStack() })
        }
        composable(Tool.Timestamp.route) {
            TimestampScreen(onBack = { navController.popBackStack() })
        }
    }
}
