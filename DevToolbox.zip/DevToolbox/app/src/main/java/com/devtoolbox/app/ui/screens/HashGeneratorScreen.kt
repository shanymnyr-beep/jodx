package com.devtoolbox.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.devtoolbox.app.ui.components.DangerButton
import com.devtoolbox.app.ui.components.MultiLineField
import com.devtoolbox.app.ui.components.OutputCard
import com.devtoolbox.app.ui.components.PrimaryButton
import com.devtoolbox.app.ui.components.SectionLabel
import com.devtoolbox.app.ui.components.ToolScaffold
import java.security.MessageDigest

private val ALGORITHMS = listOf("MD5", "SHA-1", "SHA-256", "SHA-512")

@OptIn(ExperimentalMaterial3Api::class, androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
@Composable
fun HashGeneratorScreen(onBack: () -> Unit) {
    var input by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf("SHA-256") }
    var output by remember { mutableStateOf("") }

    ToolScaffold(title = "مولّد الهاش", onBack = onBack) { mod ->
        SectionLabel("النص")
        MultiLineField(input, { input = it }, "أدخل النص", minHeight = 100)
        Spacer(Modifier.height(10.dp))
        SectionLabel("الخوارزمية")
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ALGORITHMS.forEach { algo ->
                FilterChip(
                    selected = selected == algo,
                    onClick = { selected = algo },
                    label = { Text(algo) }
                )
            }
        }
        Spacer(Modifier.height(10.dp))
        PrimaryButton("احسب الهاش", onClick = {
            output = if (input.isEmpty()) "" else hash(input, selected)
        })
        Spacer(Modifier.height(8.dp))
        DangerButton("مسح", onClick = { input = ""; output = "" })
        if (output.isNotBlank()) {
            Spacer(Modifier.height(12.dp))
            SectionLabel("النتيجة ($selected)")
            OutputCard(output, minHeight = 40)
        }
    }
}

private fun hash(input: String, algorithm: String): String {
    val bytes = MessageDigest.getInstance(algorithm).digest(input.toByteArray(Charsets.UTF_8))
    return bytes.joinToString("") { "%02x".format(it) }
}
