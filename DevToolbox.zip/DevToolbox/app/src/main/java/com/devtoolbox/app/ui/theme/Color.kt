package com.devtoolbox.app.ui.theme

import androidx.compose.ui.graphics.Color

val ColorPurpleBright = Color(0xFFD29BFF)
val ColorPurple = Color(0xFF9C5BFF)
val ColorPurpleDark = Color(0xFF5B2A86)
val ColorDarkBg = Color(0xFF160F16)
val ColorDarkCard = Color(0xFF4E4850)
val ColorWhite = Color(0xFFFFFFFF)
val ColorDarkMuted = Color(0xFFD2CBD6)
val ColorDarkOutline = Color(0xFF8C8290)
val ColorLightBg = Color(0xFFFAF7FB)
val ColorLightSurface = Color(0xFFEFE7F2)
val ColorDarkText = Color(0xFF231E24)
val ColorLightOutline = Color(0xFF766B78)
