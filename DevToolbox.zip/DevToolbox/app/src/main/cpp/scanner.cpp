#include "dex_reader.h"
#include "keyword_matcher.h"

#include <algorithm>
#include <chrono>
#include <sstream>
#include <string>
#include <vector>
#include <atomic>
#include <jni.h>

extern std::atomic_bool g_cancel;

static std::string accessFlags(uint32_t f) {
    struct Flag { uint32_t bit; const char* name; } flags[] = {
        {0x1, "public"}, {0x2, "private"}, {0x4, "protected"}, {0x8, "static"},
        {0x10, "final"}, {0x20, "synchronized"}, {0x40, "bridge"}, {0x80, "varargs"},
        {0x100, "native"}, {0x400, "abstract"}, {0x800, "strict"}, {0x1000, "synthetic"},
    };
    std::string out;
    for (const auto& flag : flags) {
        if (f & flag.bit) { if (!out.empty()) out += ' '; out += flag.name; }
    }
    if (out.empty()) out = "(none)";
    return out;
}

struct ScanCallbacks {
    void* env = nullptr;
    void* listener = nullptr;
    void* listenerClass = nullptr;
    void* onProgress = nullptr;
    void* onMatch = nullptr;
};

static void emitProgress(JNIEnv* env, jobject listener, jmethodID onProgress, int processed, int total, const std::string& className) {
    jstring cls = env->NewStringUTF(className.c_str());
    if (!cls) return;
    env->CallVoidMethod(listener, onProgress, processed, total, cls);
    env->DeleteLocalRef(cls);
}

static void emitMatch(JNIEnv* env, jobject listener, jmethodID onMatch, const std::string& payload) {
    jstring msg = env->NewStringUTF(payload.c_str());
    if (!msg) return;
    env->CallVoidMethod(listener, onMatch, msg);
    env->DeleteLocalRef(msg);
}

int scanDexFile(const std::string& dexPath, const std::string& dexName, const std::string& keywordPath, JNIEnv* env, jobject listener, jmethodID onProgress, jmethodID onMatch, std::string& error) {
    DexReader dex;
    if (!dex.openFile(dexPath, error)) return -1;
    KeywordMatcher matcher;
    if (!matcher.load(keywordPath, error)) return -2;

    const int total = static_cast<int>(dex.classCount());
    auto lastEmit = std::chrono::steady_clock::now() - std::chrono::seconds(1);
    int errors = 0;

    for (uint32_t classIndex = 0; classIndex < dex.classCount(); ++classIndex) {
        if (g_cancel.load(std::memory_order_relaxed)) return 1;
        std::string classDesc;
        if (!dex.classDescriptor(classIndex, classDesc)) { ++errors; continue; }
        std::vector<DexReader::MethodInfo> methods;
        std::string classError;
        if (!dex.getClassMethods(classIndex, methods, classError)) {
            ++errors;
            continue;
        }
        const auto now = std::chrono::steady_clock::now();
        if (classIndex == 0 || classIndex + 1 == dex.classCount() || now - lastEmit >= std::chrono::milliseconds(45)) {
            emitProgress(env, listener, onProgress, static_cast<int>(classIndex + 1), total, classDesc);
            lastEmit = now;
            if (env->ExceptionCheck()) { env->ExceptionClear(); return -3; }
        }

        for (const auto& method : methods) {
            if (g_cancel.load(std::memory_order_relaxed)) return 1;
            std::string name;
            if (!dex.methodName(method.methodIndex, name)) { ++errors; continue; }
            uint32_t proto = 0;
            if (!dex.methodProto(method.methodIndex, proto)) { ++errors; continue; }
            std::string ret;
            if (!dex.returnType(proto, ret)) { ++errors; continue; }
            // STRICT V FILTER: reject void methods before creating/adding a result.
            if (ret == "V") continue;
            const auto matches = matcher.matchAll(name);
            if (matches.empty()) continue;

            std::string sig;
            if (!dex.signature(method.methodIndex, classDesc, name, sig)) { ++errors; continue; }
            std::ostringstream payload;
            for (size_t i = 0; i < matches.size(); ++i) {
                if (i) payload << ',';
                payload << matches[i];
            }
            payload << '\x1F' << classDesc
                    << '\x1F' << name
                    << '\x1F' << sig
                    << '\x1F' << ret
                    << '\x1F' << dexName
                    << '\x1F' << method.methodIndex
                    << '\x1F' << accessFlags(method.accessFlags)
                    << '\x1F' << (method.direct ? "direct" : "virtual")
                    << '\x1F' << method.codeOff;
            emitMatch(env, listener, onMatch, payload.str());
            if (env->ExceptionCheck()) { env->ExceptionClear(); return -3; }
        }
    }
    return errors > 0 ? 2 : 0;
}
