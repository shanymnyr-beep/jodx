#pragma once

#include <string>
#include <unordered_map>
#include <vector>

class KeywordMatcher {
public:
    bool load(const std::string& path, std::string& error);
    std::vector<std::string> matchAll(const std::string& identifier) const;
    size_t keywordCount() const { return exact_.size(); }

private:
    std::unordered_map<std::string, std::string> exact_;
    static std::string asciiLower(const std::string& value);
    static std::vector<std::string> components(const std::string& identifier);
    void addKeyword(const std::string& raw);
};
