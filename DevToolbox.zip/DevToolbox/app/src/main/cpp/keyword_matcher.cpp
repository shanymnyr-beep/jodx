#include "keyword_matcher.h"

#include <cctype>
#include <fstream>
#include <sstream>

std::string KeywordMatcher::asciiLower(const std::string& value) {
    std::string out = value;
    for (char& c : out) {
        const unsigned char u = static_cast<unsigned char>(c);
        if (u < 128) c = static_cast<char>(std::tolower(u));
    }
    return out;
}

std::vector<std::string> KeywordMatcher::components(const std::string& identifier) {
    std::vector<std::string> out;
    if (identifier.empty()) return out;
    size_t start = 0;
    auto push = [&](size_t end) {
        if (end > start) out.emplace_back(identifier.substr(start, end - start));
        start = end;
    };
    for (size_t i = 0; i < identifier.size(); ++i) {
        const unsigned char c = static_cast<unsigned char>(identifier[i]);
        if (!(std::isalnum(c) || c == '_')) {
            push(i);
            start = i + 1;
            continue;
        }
        if (identifier[i] == '_') {
            push(i);
            start = i + 1;
            continue;
        }
        if (i > start && std::isupper(c)) {
            const unsigned char prev = static_cast<unsigned char>(identifier[i - 1]);
            bool boundary = std::islower(prev) || std::isdigit(prev);
            if (!boundary && i + 1 < identifier.size()) {
                const unsigned char next = static_cast<unsigned char>(identifier[i + 1]);
                boundary = std::isupper(prev) && std::islower(next);
            }
            if (boundary) push(i);
        }
    }
    if (start < identifier.size()) out.emplace_back(identifier.substr(start));
    return out;
}

void KeywordMatcher::addKeyword(const std::string& raw) {
    if (raw.empty()) return;
    const std::string key = asciiLower(raw);
    exact_.emplace(key, raw);
}

bool KeywordMatcher::load(const std::string& path, std::string& error) {
    exact_.clear();
    std::ifstream in(path, std::ios::in | std::ios::binary);
    if (!in) { error = "keywords.dat open failed"; return false; }
    std::string line;
    while (std::getline(in, line)) {
        if (!line.empty() && line.back() == '\r') line.pop_back();
        if (line.empty() || line[0] == '#') continue;
        addKeyword(line);
    }
    if (exact_.empty()) { error = "keywords.dat is empty"; return false; }
    return true;
}

std::vector<std::string> KeywordMatcher::matchAll(const std::string& identifier) const {
    std::vector<std::string> matches;
    const std::string full = asciiLower(identifier);
    if (auto it = exact_.find(full); it != exact_.end()) matches.push_back(it->second);
    for (const auto& part : components(identifier)) {
        const std::string token = asciiLower(part);
        if (auto it = exact_.find(token); it != exact_.end()) {
            bool duplicate = false;
            for (const auto& already : matches) {
                if (asciiLower(already) == token) { duplicate = true; break; }
            }
            if (!duplicate) matches.push_back(it->second);
        }
    }
    return matches;
}
