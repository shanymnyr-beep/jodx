#pragma once

#include <cstdint>
#include <string>
#include <vector>

class DexReader {
public:
    struct MethodInfo {
        uint32_t methodIndex{};
        uint32_t accessFlags{};
        uint32_t codeOff{};
        bool direct{};
    };

    DexReader() = default;
    ~DexReader();
    DexReader(const DexReader&) = delete;
    DexReader& operator=(const DexReader&) = delete;

    bool openFile(const std::string& path, std::string& error);
    void close();
    bool valid() const { return data_ != nullptr; }
    uint32_t fileSize() const { return fileSize_; }
    uint32_t classCount() const { return classDefsSize_; }

    bool classDescriptor(uint32_t classDefIndex, std::string& out) const;
    bool getClassMethods(uint32_t classDefIndex, std::vector<MethodInfo>& out, std::string& error) const;
    bool methodName(uint32_t methodIndex, std::string& out) const;
    bool methodClass(uint32_t methodIndex, uint32_t& classIndex) const;
    bool methodProto(uint32_t methodIndex, uint32_t& protoIndex) const;
    bool returnType(uint32_t protoIndex, std::string& out) const;
    bool signature(uint32_t methodIndex, const std::string& classDesc, const std::string& methodName, std::string& out) const;

private:
    const uint8_t* data_ = nullptr;
    size_t mappedSize_ = 0;
    int fd_ = -1;
    uint32_t fileSize_ = 0;
    uint32_t stringIdsSize_ = 0, stringIdsOff_ = 0;
    uint32_t typeIdsSize_ = 0, typeIdsOff_ = 0;
    uint32_t protoIdsSize_ = 0, protoIdsOff_ = 0;
    uint32_t methodIdsSize_ = 0, methodIdsOff_ = 0;
    uint32_t classDefsSize_ = 0, classDefsOff_ = 0;

    bool rangeOk(uint64_t off, uint64_t length) const;
    bool readU16(uint64_t off, uint16_t& v) const;
    bool readU32(uint64_t off, uint32_t& v) const;
    bool readUleb128(uint64_t& off, uint32_t& value) const;
    bool readString(uint32_t stringIndex, std::string& out) const;
    bool typeDescriptor(uint32_t typeIndex, std::string& out) const;
    bool readTypeList(uint32_t off, std::vector<std::string>& types) const;
};
