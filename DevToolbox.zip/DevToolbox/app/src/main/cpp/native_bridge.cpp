#include <jni.h>
#include <atomic>
#include <string>

#include "dex_reader.h"

extern int scanDexFile(const std::string& dexPath, const std::string& dexName, const std::string& keywordPath, JNIEnv* env, jobject listener, jmethodID onProgress, jmethodID onMatch, std::string& error);

std::atomic_bool g_cancel{false};

static std::string jstr(JNIEnv* env, jstring s) {
    if (!s) return {};
    const char* chars = env->GetStringUTFChars(s, nullptr);
    std::string out = chars ? chars : "";
    if (chars) env->ReleaseStringUTFChars(s, chars);
    return out;
}

extern "C" JNIEXPORT jint JNICALL
Java_com_devtoolbox_app_analyzer_NativeDexScanner_countClasses(JNIEnv* env, jobject, jstring dexPath) {
    const std::string path = jstr(env, dexPath);
    std::string error;
    DexReader reader;
    if (!reader.openFile(path, error)) return -1;
    if (reader.classCount() > static_cast<uint32_t>(INT32_MAX)) return -1;
    return static_cast<jint>(reader.classCount());
}

extern "C" JNIEXPORT jint JNICALL
Java_com_devtoolbox_app_analyzer_NativeDexScanner_scanDex(JNIEnv* env, jobject, jstring dexPath, jstring dexName, jstring keywordPath, jobject listener) {
    const std::string path = jstr(env, dexPath);
    const std::string name = jstr(env, dexName);
    const std::string keywords = jstr(env, keywordPath);
    if (!listener) return -10;

    jclass listenerClass = env->GetObjectClass(listener);
    if (!listenerClass) return -11;
    jmethodID onProgress = env->GetMethodID(listenerClass, "onProgress", "(IILjava/lang/String;)V");
    jmethodID onMatch = env->GetMethodID(listenerClass, "onMatch", "(Ljava/lang/String;)V");
    if (!onProgress || !onMatch) {
        env->DeleteLocalRef(listenerClass);
        return -12;
    }
    std::string error;
    const int result = scanDexFile(path, name, keywords, env, listener, onProgress, onMatch, error);
    env->DeleteLocalRef(listenerClass);
    return result < 0 ? result : result;
}

extern "C" JNIEXPORT void JNICALL
Java_com_devtoolbox_app_analyzer_NativeDexScanner_stop(JNIEnv*, jobject) {
    g_cancel.store(true, std::memory_order_relaxed);
}


extern "C" JNIEXPORT void JNICALL
Java_com_devtoolbox_app_analyzer_NativeDexScanner_reset(JNIEnv*, jobject) {
    g_cancel.store(false, std::memory_order_relaxed);
}
