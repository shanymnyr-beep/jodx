#include "dex_reader.h"

#include <algorithm>
#include <fcntl.h>
#include <limits>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>

namespace {
constexpr uint32_t kHeaderSize = 0x70;
constexpr uint32_t kEndian = 0x12345678;
constexpr uint32_t kMaxUlebBytes = 5;

uint32_t rd32(const uint8_t* p) {
    return static_cast<uint32_t>(p[0]) |
           (static_cast<uint32_t>(p[1]) << 8) |
           (static_cast<uint32_t>(p[2]) << 16) |
           (static_cast<uint32_t>(p[3]) << 24);
}
uint16_t rd16(const uint8_t* p) {
    return static_cast<uint16_t>(p[0]) | (static_cast<uint16_t>(p[1]) << 8);
}
}

DexReader::~DexReader() { close(); }

bool DexReader::rangeOk(uint64_t off, uint64_t length) const {
    if (off > mappedSize_) return false;
    return length <= (mappedSize_ - off);
}

bool DexReader::readU16(uint64_t off, uint16_t& v) const {
    if (!rangeOk(off, 2)) return false;
    v = rd16(data_ + off);
    return true;
}

bool DexReader::readU32(uint64_t off, uint32_t& v) const {
    if (!rangeOk(off, 4)) return false;
    v = rd32(data_ + off);
    return true;
}

bool DexReader::readUleb128(uint64_t& off, uint32_t& value) const {
    uint32_t result = 0;
    uint32_t shift = 0;
    for (uint32_t i = 0; i < kMaxUlebBytes; ++i) {
        if (!rangeOk(off, 1)) return false;
        const uint8_t b = data_[off++];
        result |= static_cast<uint32_t>(b & 0x7fU) << shift;
        if ((b & 0x80U) == 0) {
            value = result;
            return true;
        }
        shift += 7;
    }
    return false;
}

void DexReader::close() {
    if (data_ && mappedSize_) munmap(const_cast<uint8_t*>(data_), mappedSize_);
    if (fd_ >= 0) ::close(fd_);
    data_ = nullptr;
    mappedSize_ = 0;
    fd_ = -1;
    fileSize_ = 0;
    stringIdsSize_ = stringIdsOff_ = 0;
    typeIdsSize_ = typeIdsOff_ = 0;
    protoIdsSize_ = protoIdsOff_ = 0;
    methodIdsSize_ = methodIdsOff_ = 0;
    classDefsSize_ = classDefsOff_ = 0;
}

bool DexReader::openFile(const std::string& path, std::string& error) {
    close();
    fd_ = ::open(path.c_str(), O_RDONLY | O_CLOEXEC);
    if (fd_ < 0) { error = "open failed"; return false; }
    struct stat st{};
    if (fstat(fd_, &st) != 0 || st.st_size <= 0) { error = "stat failed"; close(); return false; }
    mappedSize_ = static_cast<size_t>(st.st_size);
    if (mappedSize_ < kHeaderSize) { error = "DEX header truncated"; close(); return false; }
    void* mapped = mmap(nullptr, mappedSize_, PROT_READ, MAP_PRIVATE, fd_, 0);
    if (mapped == MAP_FAILED) { error = "mmap failed"; close(); return false; }
    data_ = static_cast<const uint8_t*>(mapped);

    if (!(data_[0] == 'd' && data_[1] == 'e' && data_[2] == 'x' && data_[3] == '\n' && data_[7] == 0)) {
        error = "invalid DEX magic"; close(); return false;
    }
    const char version = static_cast<char>(data_[4]);
    if (version < '0' || version > '9') { error = "unsupported DEX version"; close(); return false; }
    if (data_[5] < '0' || data_[5] > '9' || data_[6] < '0' || data_[6] > '9') {
        error = "invalid DEX version"; close(); return false;
    }
    uint32_t declaredSize = 0, headerSize = 0, endian = 0;
    if (!readU32(0x20, declaredSize) || !readU32(0x24, headerSize) || !readU32(0x28, endian)) {
        error = "DEX header unreadable"; close(); return false;
    }
    if (headerSize != kHeaderSize || declaredSize > mappedSize_ || declaredSize < headerSize) {
        error = "invalid DEX size/header"; close(); return false;
    }
    if (endian != kEndian) {
        error = "unsupported endian tag"; close(); return false;
    }
    fileSize_ = declaredSize;
    const auto readHeaderPair = [this](uint32_t sizeOff, uint32_t offOff, uint32_t& size, uint32_t& off) {
        return readU32(sizeOff, size) && readU32(offOff, off);
    };
    if (!readHeaderPair(0x38, 0x3c, stringIdsSize_, stringIdsOff_) ||
        !readHeaderPair(0x40, 0x44, typeIdsSize_, typeIdsOff_) ||
        !readHeaderPair(0x48, 0x4c, protoIdsSize_, protoIdsOff_) ||
        !readHeaderPair(0x58, 0x5c, methodIdsSize_, methodIdsOff_) ||
        !readHeaderPair(0x60, 0x64, classDefsSize_, classDefsOff_)) {
        error = "DEX index tables unreadable"; close(); return false;
    }
    if (!rangeOk(stringIdsOff_, static_cast<uint64_t>(stringIdsSize_) * 4) ||
        !rangeOk(typeIdsOff_, static_cast<uint64_t>(typeIdsSize_) * 4) ||
        !rangeOk(protoIdsOff_, static_cast<uint64_t>(protoIdsSize_) * 12) ||
        !rangeOk(methodIdsOff_, static_cast<uint64_t>(methodIdsSize_) * 8) ||
        !rangeOk(classDefsOff_, static_cast<uint64_t>(classDefsSize_) * 32)) {
        error = "DEX table out of bounds"; close(); return false;
    }
    return true;
}

bool DexReader::readString(uint32_t stringIndex, std::string& out) const {
    if (stringIndex >= stringIdsSize_) return false;
    uint32_t dataOff = 0;
    if (!readU32(static_cast<uint64_t>(stringIdsOff_) + static_cast<uint64_t>(stringIndex) * 4, dataOff)) return false;
    if (!rangeOk(dataOff, 1)) return false;
    uint64_t cur = dataOff;
    uint32_t utf16Size = 0;
    if (!readUleb128(cur, utf16Size)) return false;
    (void)utf16Size;
    const uint64_t start = cur;
    while (rangeOk(cur, 1)) {
        if (data_[cur++] == 0) {
            const uint64_t len = cur - start - 1;
            out.assign(reinterpret_cast<const char*>(data_ + start), static_cast<size_t>(len));
            return true;
        }
    }
    return false;
}

bool DexReader::typeDescriptor(uint32_t typeIndex, std::string& out) const {
    if (typeIndex >= typeIdsSize_) return false;
    uint32_t stringIndex = 0;
    if (!readU32(static_cast<uint64_t>(typeIdsOff_) + static_cast<uint64_t>(typeIndex) * 4, stringIndex)) return false;
    return readString(stringIndex, out);
}

bool DexReader::classDescriptor(uint32_t classDefIndex, std::string& out) const {
    if (classDefIndex >= classDefsSize_) return false;
    uint32_t classIdx = 0;
    if (!readU32(static_cast<uint64_t>(classDefsOff_) + static_cast<uint64_t>(classDefIndex) * 32, classIdx)) return false;
    return typeDescriptor(classIdx, out);
}

bool DexReader::getClassMethods(uint32_t classDefIndex, std::vector<MethodInfo>& out, std::string& error) const {
    out.clear();
    if (classDefIndex >= classDefsSize_) { error = "class index out of range"; return false; }
    uint32_t classDataOff = 0;
    if (!readU32(static_cast<uint64_t>(classDefsOff_) + static_cast<uint64_t>(classDefIndex) * 32 + 24, classDataOff)) {
        error = "class_data_off unreadable"; return false;
    }
    if (classDataOff == 0) return true;
    if (!rangeOk(classDataOff, 1)) { error = "class_data_off out of bounds"; return false; }
    uint64_t cur = classDataOff;
    uint32_t staticFields = 0, instanceFields = 0, directMethods = 0, virtualMethods = 0;
    if (!readUleb128(cur, staticFields) || !readUleb128(cur, instanceFields) ||
        !readUleb128(cur, directMethods) || !readUleb128(cur, virtualMethods)) {
        error = "malformed class data header"; return false;
    }
    auto skipFields = [this, &cur](uint32_t count) -> bool {
        for (uint32_t i = 0; i < count; ++i) {
            uint32_t a = 0, b = 0;
            if (!readUleb128(cur, a) || !readUleb128(cur, b)) return false;
        }
        return true;
    };
    if (!skipFields(staticFields) || !skipFields(instanceFields)) {
        error = "malformed field list"; return false;
    }
    auto readMethods = [this, &cur, &out](uint32_t count, bool direct) -> bool {
        uint32_t methodIdx = 0;
        for (uint32_t i = 0; i < count; ++i) {
            uint32_t diff = 0, access = 0, codeOff = 0;
            if (!readUleb128(cur, diff) || !readUleb128(cur, access) || !readUleb128(cur, codeOff)) return false;
            if (diff > std::numeric_limits<uint32_t>::max() - methodIdx) return false;
            methodIdx += diff;
            if (methodIdx >= methodIdsSize_) return false;
            out.push_back(MethodInfo{methodIdx, access, codeOff, direct});
        }
        return true;
    };
    if (!readMethods(directMethods, true) || !readMethods(virtualMethods, false)) {
        error = "malformed method list"; return false;
    }
    return true;
}

bool DexReader::methodName(uint32_t methodIndex, std::string& out) const {
    if (methodIndex >= methodIdsSize_) return false;
    uint32_t nameIdx = 0;
    if (!readU32(static_cast<uint64_t>(methodIdsOff_) + static_cast<uint64_t>(methodIndex) * 8 + 4, nameIdx)) return false;
    return readString(nameIdx, out);
}

bool DexReader::methodClass(uint32_t methodIndex, uint32_t& classIndex) const {
    if (methodIndex >= methodIdsSize_) return false;
    uint16_t c = 0;
    if (!readU16(static_cast<uint64_t>(methodIdsOff_) + static_cast<uint64_t>(methodIndex) * 8, c)) return false;
    classIndex = c;
    return classIndex < typeIdsSize_;
}

bool DexReader::methodProto(uint32_t methodIndex, uint32_t& protoIndex) const {
    if (methodIndex >= methodIdsSize_) return false;
    uint16_t p = 0;
    if (!readU16(static_cast<uint64_t>(methodIdsOff_) + static_cast<uint64_t>(methodIndex) * 8 + 2, p)) return false;
    protoIndex = p;
    return protoIndex < protoIdsSize_;
}

bool DexReader::returnType(uint32_t protoIndex, std::string& out) const {
    if (protoIndex >= protoIdsSize_) return false;
    uint32_t returnTypeIdx = 0;
    if (!readU32(static_cast<uint64_t>(protoIdsOff_) + static_cast<uint64_t>(protoIndex) * 12 + 4, returnTypeIdx)) return false;
    return typeDescriptor(returnTypeIdx, out);
}

bool DexReader::readTypeList(uint32_t off, std::vector<std::string>& types) const {
    types.clear();
    if (off == 0) return true;
    if (!rangeOk(off, 4)) return false;
    uint32_t size = 0;
    if (!readU32(off, size)) return false;
    if (static_cast<uint64_t>(size) * 2 > mappedSize_ - (off + 4ULL)) return false;
    types.reserve(size);
    for (uint32_t i = 0; i < size; ++i) {
        uint16_t typeIdx = 0;
        if (!readU16(static_cast<uint64_t>(off) + 4 + static_cast<uint64_t>(i) * 2, typeIdx)) return false;
        std::string t;
        if (!typeDescriptor(typeIdx, t)) return false;
        types.push_back(std::move(t));
    }
    return true;
}

bool DexReader::signature(uint32_t methodIndex, const std::string& classDesc, const std::string& methodName, std::string& out) const {
    uint32_t proto = 0;
    if (!methodProto(methodIndex, proto)) return false;
    uint32_t paramsOff = 0;
    if (!readU32(static_cast<uint64_t>(protoIdsOff_) + static_cast<uint64_t>(proto) * 12 + 8, paramsOff)) return false;
    std::vector<std::string> params;
    if (!readTypeList(paramsOff, params)) return false;
    std::string ret;
    if (!returnType(proto, ret)) return false;
    out = classDesc + "->" + methodName + "(";
    for (const auto& t : params) out += t;
    out += ")" + ret;
    return true;
}
