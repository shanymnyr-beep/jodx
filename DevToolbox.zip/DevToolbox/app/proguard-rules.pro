# Keep the Kotlin/JNI bridge names used by the native library.
-keep class com.devtoolbox.app.analyzer.NativeDexScanner { *; }
-keep class com.devtoolbox.app.analyzer.NativeDexScanner$Listener { *; }

# Compose reflection-free runtime does not require blanket keep rules.
