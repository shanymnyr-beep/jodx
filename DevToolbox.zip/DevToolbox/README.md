# DevToolbox — APK Method & Purchase Analyzer

This project adds a read-only native DEX scanner as the first DevToolbox tool.

- Multi-dex: classes.dex, classes2.dex, classes3.dex, …
- Native C++ DEX table reader with mmap + bounds checking.
- Full keyword database generated from the supplied specification (640 unique case-insensitive entries).
- Strict `V` return-type filter before result creation.
- Exact identifier/component matching to reduce noise.
- Batched JNI result delivery and background scanning.
- Stop/cancel keeps only results reached before cancellation.
- No APK patching, injection, rebuilding, resigning or payment bypass.
- Telegram button: https://t.me/VantaV_X

## Build
Use the supplied GitHub Actions workflow with JDK 17, Gradle 8.9, AGP 8.7.3, Android API 35, Build Tools 35.0.0, NDK 26.3.11579264 and CMake 3.22.1.
