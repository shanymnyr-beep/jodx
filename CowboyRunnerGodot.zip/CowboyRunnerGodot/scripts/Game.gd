extends Node2D

const W := 1280.0
const H := 720.0
const PLAYER_START := Vector2(260, 430)
const GRAVITY := 1800.0
const RUN_SPEED := 420.0
const JUMP_VELOCITY := -720.0
const GROUND_Y := 585.0
const CHUNK_WIDTH := 720.0

var player: CharacterBody2D
var camera: Camera2D
var background: Sprite2D
var sprite: Sprite2D
var anim_timer := 0.0
var run_frames: Array[Texture2D] = []
var jump_frames: Array[Texture2D] = []
var current_frame := 0
var is_jumping := false
var game_started := false
var game_over := false
var paused := false
var score := 0
var coins := 0
var high_score := 0
var distance := 0.0
var spawned_until := 0.0
var rng := RandomNumberGenerator.new()
var grounds: Array[Node2D] = []
var coin_nodes: Array[Area2D] = []
var obstacle_nodes: Array[StaticBody2D] = []

var score_label: Label
var coin_label: Label
var high_label: Label
var menu_panel: Control
var gameover_panel: Control
var pause_panel: Control
var jump_hint: Label
var music: AudioStreamPlayer
var coin_sfx: AudioStreamPlayer
var death_sfx: AudioStreamPlayer

func _ready() -> void:
    rng.randomize()
    high_score = int(ProjectSettings.get_setting("application/config/high_score", 0))
    _load_textures()
    _build_world()
    _build_ui()
    _show_menu()

func _load_textures() -> void:
    for i in range(7):
        run_frames.append(load("res://assets/sprites/frames/run%d.png" % i))
        jump_frames.append(load("res://assets/sprites/frames/jump%d.png" % i))

func _build_world() -> void:
    background = Sprite2D.new()
    background.texture = load("res://assets/sprites/game_background.jpg")
    background.position = Vector2(PLAYER_START.x + W/2.0, H/2.0)
    background.scale = Vector2(W/1280.0, H/640.0)
    background.z_index = -100
    add_child(background)

    # soft dark vignette-style sky band
    var top := ColorRect.new()
    top.color = Color(0.05,0.06,0.11,0.10)
    top.position = Vector2(0,0)
    top.size = Vector2(W,180)
    top.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(top)

    _create_player()
    _spawn_chunk(0.0, true)
    _spawn_chunk(CHUNK_WIDTH, false)
    _spawn_chunk(CHUNK_WIDTH * 2.0, false)
    spawned_until = CHUNK_WIDTH * 3.0

func _create_player() -> void:
    player = CharacterBody2D.new()
    player.name = "Player"
    player.position = PLAYER_START
    player.collision_layer = 1
    player.collision_mask = 1
    add_child(player)

    var shape := CollisionShape2D.new()
    var capsule := CapsuleShape2D.new()
    capsule.radius = 38
    capsule.height = 150
    shape.shape = capsule
    shape.position = Vector2(0, 12)
    player.add_child(shape)

    sprite = Sprite2D.new()
    sprite.texture = run_frames[0]
    sprite.scale = Vector2(0.62, 0.62)
    sprite.position = Vector2(0, -42)
    sprite.z_index = 10
    player.add_child(sprite)

    camera = Camera2D.new()
    camera.position_smoothing_enabled = true
    camera.position_smoothing_speed = 7.0
    camera.limit_left = 0
    camera.limit_top = 0
    camera.limit_bottom = H
    camera.enabled = true
    player.add_child(camera)


func _build_ui() -> void:
    var layer := CanvasLayer.new()
    layer.layer = 50
    layer.process_mode = Node.PROCESS_MODE_ALWAYS
    add_child(layer)

    score_label = _label(layer, "SCORE 000000", Vector2(30,24), 30)
    coin_label = _label(layer, "COINS 000", Vector2(30,62), 22)
    high_label = _label(layer, "BEST 000000", Vector2(30,94), 18)
    high_label.modulate.a = 0.85

    jump_hint = _label(layer, "TAP / SPACE TO JUMP", Vector2(W-330, H-55), 18)
    jump_hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
    jump_hint.modulate.a = 0.85

    menu_panel = _make_overlay(layer)
    gameover_panel = _make_overlay(layer)
    pause_panel = _make_overlay(layer)
    gameover_panel.visible = false
    pause_panel.visible = false
    menu_panel.visible = false

    _build_menu(menu_panel)
    _build_gameover(gameover_panel)
    _build_pause(pause_panel)

    music = AudioStreamPlayer.new()
    music.stream = _safe_load("res://assets/sounds/cowboy theme.mp3")
    music.volume_db = -9
    music.autoplay = false
    layer.add_child(music)

    coin_sfx = AudioStreamPlayer.new()
    coin_sfx.stream = _safe_load("res://assets/sounds/coin sound.wav")
    coin_sfx.volume_db = -2
    layer.add_child(coin_sfx)

    death_sfx = AudioStreamPlayer.new()
    death_sfx.stream = _safe_load("res://assets/sounds/Dead.mp3")
    death_sfx.volume_db = -3
    layer.add_child(death_sfx)

func _safe_load(path: String) -> AudioStream:
    var res = load(path)
    return res as AudioStream

func _label(parent: Node, text: String, pos: Vector2, size: int) -> Label:
    var l := Label.new()
    l.text = text
    l.position = pos
    l.add_theme_font_size_override("font_size", size)
    l.add_theme_color_override("font_color", Color(1,0.96,0.82))
    l.add_theme_color_override("font_shadow_color", Color(0,0,0,0.75))
    l.add_theme_constant_override("shadow_offset_x", 3)
    l.add_theme_constant_override("shadow_offset_y", 3)
    parent.add_child(l)
    return l

func _make_overlay(parent: Node) -> Control:
    var c := Control.new()
    c.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    c.mouse_filter = Control.MOUSE_FILTER_STOP
    parent.add_child(c)
    var dim := ColorRect.new()
    dim.color = Color(0,0,0,0.55)
    dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    dim.mouse_filter = Control.MOUSE_FILTER_IGNORE
    c.add_child(dim)
    return c

func _panel_style() -> StyleBoxFlat:
    var s := StyleBoxFlat.new()
    s.bg_color = Color(0.07,0.06,0.05,0.92)
    s.border_color = Color(0.78,0.55,0.25,0.9)
    s.set_border_width_all(2)
    s.corner_radius_top_left = 18
    s.corner_radius_top_right = 18
    s.corner_radius_bottom_left = 18
    s.corner_radius_bottom_right = 18
    return s

func _button(parent: Node, text: String, pos: Vector2, size: Vector2, callback: Callable) -> Button:
    var b := Button.new()
    b.text = text
    b.position = pos
    b.size = size
    b.add_theme_font_size_override("font_size", 28)
    b.add_theme_stylebox_override("normal", _panel_style())
    b.add_theme_stylebox_override("hover", _panel_style())
    b.pressed.connect(callback)
    parent.add_child(b)
    return b

func _title(parent: Node, text: String, y: float) -> void:
    var l := _label(parent, text, Vector2(0,y), 52)
    l.size = Vector2(W,70)
    l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    l.add_theme_color_override("font_color", Color(1,0.74,0.25))

func _build_menu(panel: Control) -> void:
    _title(panel, "COWBOY RUNNER", 110)
    var sub := _label(panel, "RUN  •  JUMP  •  SURVIVE  •  COLLECT", Vector2(0,190), 20)
    sub.size = Vector2(W,40); sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    _button(panel, "START RUN", Vector2(W/2-150,280), Vector2(300,70), _start_game)
    var info := _label(panel, "Desktop: SPACE / ↑    Mobile: TAP", Vector2(0,380), 18)
    info.size=Vector2(W,40); info.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; info.modulate.a=0.8
    var best := _label(panel, "BEST  %06d" % high_score, Vector2(0,440), 25)
    best.name = "BestLabel"; best.size=Vector2(W,40); best.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER

func _build_gameover(panel: Control) -> void:
    _title(panel, "RUN OVER", 130)
    var result := _label(panel, "", Vector2(0,220), 28)
    result.name = "Result"
    result.size=Vector2(W,90); result.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
    _button(panel, "RUN AGAIN", Vector2(W/2-150,340), Vector2(300,70), _start_game)
    _button(panel, "MENU", Vector2(W/2-150,430), Vector2(300,60), _back_to_menu)

func _build_pause(panel: Control) -> void:
    _title(panel, "PAUSED", 160)
    _button(panel, "RESUME", Vector2(W/2-150,290), Vector2(300,70), _toggle_pause)
    _button(panel, "QUIT RUN", Vector2(W/2-150,380), Vector2(300,60), _back_to_menu)

func _show_menu() -> void:
    menu_panel.visible = true
    gameover_panel.visible = false
    pause_panel.visible = false
    game_started = false
    paused = true
    jump_hint.visible = false
    if music: music.stop()

func _start_game() -> void:
    _clear_dynamic_world()
    player.position = PLAYER_START
    player.velocity = Vector2.ZERO
    score = 0; coins = 0; distance = 0.0
    game_over = false
    paused = false
    game_started = true
    spawned_until = 0.0
    _spawn_chunk(0.0, true)
    _spawn_chunk(CHUNK_WIDTH, false)
    _spawn_chunk(CHUNK_WIDTH*2.0, false)
    spawned_until = CHUNK_WIDTH*3.0
    menu_panel.visible = false
    gameover_panel.visible = false
    pause_panel.visible = false
    jump_hint.visible = true
    if music and music.stream: music.play()

func _back_to_menu() -> void:
    _show_menu()

func _toggle_pause() -> void:
    if not game_started or game_over: return
    paused = not paused
    pause_panel.visible = paused
    jump_hint.visible = not paused

func _unhandled_input(event: InputEvent) -> void:
    if event is InputEventKey and event.pressed and not event.echo:
        if event.physical_keycode == KEY_ESCAPE:
            if game_started: _toggle_pause()
        elif (event.physical_keycode == KEY_SPACE or event.physical_keycode == KEY_UP) and game_started and not paused:
            _jump()
    elif event is InputEventScreenTouch and event.pressed and game_started and not paused:
        _jump()

func _jump() -> void:
    if not is_instance_valid(player): return
    if player.is_on_floor():
        player.velocity.y = JUMP_VELOCITY
        is_jumping = true

func _physics_process(delta: float) -> void:
    if not game_started or paused or game_over: return
    player.velocity.x = RUN_SPEED
    player.velocity.y += GRAVITY * delta
    player.move_and_slide()
    for i in range(player.get_slide_collision_count()):
        var collision := player.get_slide_collision(i)
        if collision and collision.get_collider() is StaticBody2D and collision.get_collider().get_meta("hazard", false):
            _die()
            return
    if background:
        background.position.x = player.position.x + W/2.0 - PLAYER_START.x
    distance = max(distance, player.position.x - PLAYER_START.x)
    score = int(distance * 0.15) + coins * 10
    _update_anim(delta)
    _update_world()
    _cleanup_world()
    _update_ui()
    if player.position.y > H + 250:
        _die()

func _update_anim(delta: float) -> void:
    anim_timer += delta
    var frames := jump_frames if not player.is_on_floor() else run_frames
    var speed := 0.09 if player.is_on_floor() else 0.12
    if anim_timer >= speed:
        anim_timer = 0.0
        current_frame = (current_frame + 1) % frames.size()
        sprite.texture = frames[current_frame]
    sprite.flip_h = false

func _update_world() -> void:
    if player.position.x + 1300.0 > spawned_until:
        _spawn_chunk(spawned_until, false)
        spawned_until += CHUNK_WIDTH

func _spawn_chunk(start_x: float, first: bool) -> void:
    var y := GROUND_Y + rng.randi_range(-18, 18)
    if first: y = GROUND_Y
    var segment_count := 4
    for i in range(segment_count):
        var x := start_x + i * 180.0
        var tex := load("res://assets/sprites/ground%d.png" % ((i + int(start_x/CHUNK_WIDTH)) % 10)) as Texture2D
        _make_ground(Vector2(x, y))
        if i > 0 and rng.randf() < 0.78:
            _make_coin(Vector2(x + rng.randi_range(30,120), y - rng.randi_range(110,190)))
        if i > 0 and rng.randf() < 0.25:
            _make_obstacle(Vector2(x + rng.randi_range(70,145), y - 55), rng.randf() < 0.5)
    # a raised mini-platform sometimes
    if not first and rng.randf() < 0.28:
        _make_ground(Vector2(start_x + 550, y - 110), true)

func _make_ground(pos: Vector2, raised := false) -> void:
    var body := StaticBody2D.new()
    body.position = pos + Vector2(0, 35 if not raised else 0)
    body.collision_layer = 1
    body.collision_mask = 1
    var shape := CollisionShape2D.new()
    var rect := RectangleShape2D.new()
    rect.size = Vector2(178, 80)
    shape.shape = rect
    shape.position.y = 28
    body.add_child(shape)
    var sp := Sprite2D.new()
    sp.texture = load("res://assets/sprites/ground%d.png" % rng.randi_range(0,9))
    sp.scale = Vector2(1.55,1.0)
    sp.position = Vector2(0, 15)
    body.add_child(sp)
    body.add_to_group("grounds")
    add_child(body)
    grounds.append(body)

func _make_coin(pos: Vector2) -> void:
    var a := Area2D.new()
    a.position = pos
    a.collision_layer = 2
    a.collision_mask = 1
    var shape := CollisionShape2D.new()
    var circle := CircleShape2D.new(); circle.radius = 34
    shape.shape = circle
    a.add_child(shape)
    var sp := Sprite2D.new(); sp.texture = load("res://assets/sprites/coin.png"); sp.scale = Vector2(0.14,0.14); a.add_child(sp)
    a.body_entered.connect(func(body):
        if body == player:
            coins += 1
            if coin_sfx and coin_sfx.stream: coin_sfx.play()
            a.queue_free()
    )
    add_child(a); coin_nodes.append(a)

func _make_obstacle(pos: Vector2, spikes: bool) -> void:
    var b := StaticBody2D.new()
    b.position = pos
    b.collision_layer = 1; b.collision_mask = 1
    var shape := CollisionShape2D.new()
    var rect := RectangleShape2D.new()
    rect.size = Vector2(85 if spikes else 74, 70)
    shape.shape = rect; shape.position.y = 20
    b.add_child(shape)
    var sp := Sprite2D.new()
    sp.texture = load("res://assets/sprites/%s.png" % ("spikes" if spikes else "crate_0"))
    sp.scale = Vector2(0.35 if spikes else 0.18, 0.35 if spikes else 0.18)
    sp.position.y = 0
    b.add_child(sp)
    b.set_meta("hazard", true)
    add_child(b); obstacle_nodes.append(b)

func _die() -> void:
    if game_over: return
    game_over = true
    game_started = false
    paused = false
    if music: music.stop()
    if death_sfx and death_sfx.stream: death_sfx.play()
    high_score = max(high_score, score)
    ProjectSettings.set_setting("application/config/high_score", high_score)
    ProjectSettings.save()
    var result: Label = gameover_panel.get_node("Result")
    result.text = "SCORE  %06d\nCOINS  %03d\nBEST   %06d" % [score, coins, high_score]
    gameover_panel.visible = true
    jump_hint.visible = false

func _update_ui() -> void:
    score_label.text = "SCORE %06d" % score
    coin_label.text = "COINS %03d" % coins
    high_label.text = "BEST  %06d" % high_score

func _cleanup_world() -> void:
    var left := player.position.x - 1600.0
    for n in grounds.duplicate():
        if is_instance_valid(n) and n.position.x < left:
            grounds.erase(n); n.queue_free()
    for n in coin_nodes.duplicate():
        if not is_instance_valid(n) or n.position.x < left:
            coin_nodes.erase(n)
            if is_instance_valid(n): n.queue_free()
    for n in obstacle_nodes.duplicate():
        if is_instance_valid(n) and n.position.x < left:
            obstacle_nodes.erase(n); n.queue_free()

func _clear_dynamic_world() -> void:
    for n in grounds:
        if is_instance_valid(n):
            n.queue_free()
    for n in coin_nodes:
        if is_instance_valid(n):
            n.queue_free()
    for n in obstacle_nodes:
        if is_instance_valid(n):
            n.queue_free()
    grounds.clear(); coin_nodes.clear(); obstacle_nodes.clear()
