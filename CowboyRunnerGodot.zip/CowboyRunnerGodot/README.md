# Cowboy Runner — Godot 4 Edition

Converted from the supplied legacy Unity 5.6.1 project into a Godot 4.7.2 project.

## Included
- Endless runner gameplay rebuilt with Godot 2D physics.
- Cowboy run/jump animation frames extracted from the supplied Unity sprite atlases.
- Original desert background, ground sprites, coin, crate, spikes, fonts and audio retained where usable.
- Touch/keyboard jump input.
- Score, coins, high score, pause, restart and game-over flow.
- Android ARM64 export preset.
- GitHub Actions workflow for automated APK building.

## Build locally
Open the folder in Godot 4.7.2 and press Run Project.

## GitHub build
Push the repository and run **Actions → Build Cowboy Runner**. The workflow targets Godot 4.7.2 and exports an Android ARM64 APK.

This is a native Godot rebuild of the gameplay rather than a binary Unity-to-Godot importer. Unity-specific scenes, prefabs, C# scripts and serialized animator data were recreated in Godot.
