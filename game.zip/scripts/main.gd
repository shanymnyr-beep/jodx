extends Node3D

const PLAYER_SCENE := preload("res://scenes/Player.tscn")
const CITY_SCRIPT := preload("res://scripts/city.gd")

const SKINS := [
    ["Human Male", "res://assets/characters/Skins/humanMaleA.png"],
    ["Human Female", "res://assets/characters/Skins/humanFemaleA.png"],
    ["Zombie Male", "res://assets/characters/Skins/zombieMaleA.png"],
    ["Zombie Female", "res://assets/characters/Skins/zombieFemaleA.png"]
]

var menu: Control

func _ready() -> void:
    _show_character_select()

func _show_character_select() -> void:
    menu = Control.new()
    menu.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(menu)

    var bg := ColorRect.new()
    bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    bg.color = Color("0b1018")
    menu.add_child(bg)

    var title := Label.new()
    title.text = "CITY WANDERER"
    title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    title.position = Vector2(0, 55)
    title.size = Vector2(1280, 70)
    title.add_theme_font_size_override("font_size", 44)
    menu.add_child(title)

    var sub := Label.new()
    sub.text = "Choose a character"
    sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    sub.position = Vector2(0, 125)
    sub.size = Vector2(1280, 42)
    sub.add_theme_font_size_override("font_size", 21)
    menu.add_child(sub)

    var row := HBoxContainer.new()
    row.position = Vector2(95, 215)
    row.size = Vector2(1090, 180)
    row.add_theme_constant_override("separation", 18)
    menu.add_child(row)

    for skin in SKINS:
        var card := VBoxContainer.new()
        card.custom_minimum_size = Vector2(255, 170)
        row.add_child(card)

        var preview := TextureRect.new()
        var tex = load(skin[1])
        if tex:
            preview.texture = tex
        preview.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
        preview.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
        preview.custom_minimum_size = Vector2(255, 95)
        card.add_child(preview)

        var b := Button.new()
        b.text = skin[0]
        b.custom_minimum_size = Vector2(255, 60)
        b.add_theme_font_size_override("font_size", 18)
        b.pressed.connect(_start_game.bind(skin[1]))
        card.add_child(b)

    var info := Label.new()
    info.text = "Walk around the suburban neighborhood • WASD / touch • Swipe to look • Jump"
    info.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    info.position = Vector2(20, 470)
    info.size = Vector2(1240, 48)
    info.add_theme_font_size_override("font_size", 17)
    menu.add_child(info)

func _start_game(skin_path: String) -> void:
    if is_instance_valid(menu):
        menu.queue_free()

    var world := Node3D.new()
    world.name = "World"
    add_child(world)
    CITY_SCRIPT.build_city(world)

    var player := PLAYER_SCENE.instantiate()
    player.position = Vector3(0, 0.12, 0)
    player.set("skin_path", skin_path)
    world.add_child(player)
