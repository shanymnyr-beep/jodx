extends Node

const BUILDINGS = [
	"building-type-a.glb", "building-type-b.glb", "building-type-c.glb", "building-type-d.glb",
	"building-type-e.glb", "building-type-f.glb", "building-type-g.glb", "building-type-h.glb",
	"building-type-i.glb", "building-type-j.glb", "building-type-k.glb", "building-type-l.glb",
	"building-type-m.glb", "building-type-n.glb", "building-type-o.glb", "building-type-p.glb",
	"building-type-q.glb", "building-type-r.glb", "building-type-s.glb", "building-type-t.glb"
]
const CITY_PATH = "res://assets/city/GLB format/"

static func build_city(root: Node3D) -> void:
	var env = WorldEnvironment.new()
	var e = Environment.new()
	e.background_mode = Environment.BG_COLOR
	e.background_color = Color("7d93a8")
	e.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	e.ambient_light_color = Color("dbe7f2")
	e.ambient_light_energy = 0.8
	e.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.environment = e
	root.add_child(env)

	var sun = DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-55, -30, 0)
	sun.light_energy = 1.1
	sun.shadow_enabled = true
	root.add_child(sun)

	_make_ground(root)

	var idx := 0
	for z in range(-3, 4):
		for x in range(-3, 4):
			if x == 0 and z == 0:
				continue
			var path = CITY_PATH + BUILDINGS[idx % BUILDINGS.size()]
			var packed = load(path)
			if packed:
				var building = packed.instantiate()
				building.position = Vector3(x * 18.0, 0, z * 18.0)
				building.rotation_degrees.y = float((idx * 37) % 360)
				building.scale = Vector3.ONE * 1.5
				root.add_child(building)
				_add_collisions(building)
			idx += 1

	for i in range(-4, 5):
		_add_prop(root, "path-long.glb", Vector3(i * 12.0, 0.02, 0), Vector3(0, 0, 0))
		_add_prop(root, "path-long.glb", Vector3(0, 0.03, i * 12.0), Vector3(0, 90, 0))

	for i in range(-5, 6):
		_add_prop(root, "tree-small.glb", Vector3(i * 9.0, 0, 38), Vector3.ZERO)
		_add_prop(root, "tree-small.glb", Vector3(i * 9.0, 0, -38), Vector3.ZERO)

static func _make_ground(root: Node3D) -> void:
	var body = StaticBody3D.new()
	body.name = "Ground"
	var mesh = PlaneMesh.new()
	mesh.size = Vector2(150, 150)
	var mi = MeshInstance3D.new()
	mi.mesh = mesh
	var mat = StandardMaterial3D.new()
	mat.albedo_color = Color("59614f")
	mat.roughness = 1.0
	mi.material_override = mat
	body.add_child(mi)
	var shape = CollisionShape3D.new()
	var box = BoxShape3D.new()
	box.size = Vector3(150, 0.2, 150)
	shape.shape = box
	shape.position.y = -0.1
	body.add_child(shape)
	root.add_child(body)

static func _add_prop(root: Node3D, filename: String, pos: Vector3, rot: Vector3) -> void:
	var packed = load(CITY_PATH + filename)
	if packed:
		var n = packed.instantiate()
		n.position = pos
		n.rotation_degrees = rot
		n.scale = Vector3.ONE * 1.2
		root.add_child(n)

static func _add_collisions(node: Node) -> void:
	for child in node.get_children():
		if child is MeshInstance3D and child.mesh:
			var body = StaticBody3D.new()
			var cs = CollisionShape3D.new()
			cs.shape = child.mesh.create_trimesh_shape()
			body.transform = child.transform
			node.add_child(body)
		elif child.get_child_count() > 0:
			_add_collisions(child)
