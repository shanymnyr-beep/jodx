extends Node

const CITY_ROOT := "res://assets/city_kit/Models/GLB format/"

const BUILDINGS := [
    "building-type-a.glb", "building-type-b.glb", "building-type-c.glb", "building-type-d.glb",
    "building-type-e.glb", "building-type-f.glb", "building-type-g.glb", "building-type-h.glb",
    "building-type-i.glb", "building-type-j.glb", "building-type-k.glb", "building-type-l.glb",
    "building-type-m.glb", "building-type-n.glb", "building-type-o.glb", "building-type-p.glb",
    "building-type-q.glb", "building-type-r.glb", "building-type-s.glb", "building-type-t.glb",
    "building-type-u.glb"
]

static func build_city(root: Node3D) -> void:
    _environment(root)
    _ground(root)
    _road_grid(root)
    _neighborhood(root)
    _trees(root)

static func _environment(root: Node3D) -> void:
    var env_node := WorldEnvironment.new()
    env_node.name = "Environment"
    var env := Environment.new()
    env.background_mode = Environment.BG_COLOR
    env.background_color = Color("8ba0b4")
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color("d9e6d9")
    env.ambient_light_energy = 1.05
    env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    env_node.environment = env
    root.add_child(env_node)

    var sun := DirectionalLight3D.new()
    sun.name = "Sun"
    sun.rotation_degrees = Vector3(-52, -32, 0)
    sun.light_energy = 1.2
    sun.shadow_enabled = true
    root.add_child(sun)

static func _ground(root: Node3D) -> void:
    var ground := StaticBody3D.new()
    ground.name = "GrassGround"

    var mesh := PlaneMesh.new()
    mesh.size = Vector2(220, 220)
    var mi := MeshInstance3D.new()
    mi.mesh = mesh
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color("b7d7a7")
    mat.roughness = 1.0
    mi.material_override = mat
    ground.add_child(mi)

    var collision := CollisionShape3D.new()
    var box := BoxShape3D.new()
    box.size = Vector3(220, 0.2, 220)
    collision.shape = box
    collision.position.y = -0.1
    ground.add_child(collision)
    root.add_child(ground)

static func _road_grid(root: Node3D) -> void:
    # Main avenues with Kenney path pieces.
    for i in range(-7, 8):
        _add(root, "path-long.glb", Vector3(float(i) * 12.0, 0.02, 0), 90.0, 1.65)
        _add(root, "path-long.glb", Vector3(0, 0.025, float(i) * 12.0), 0.0, 1.65)

    for i in range(-6, 7):
        _add(root, "driveway-short.glb", Vector3(float(i) * 15.0, 0.025, 19.0), 0.0, 1.35)
        _add(root, "driveway-short.glb", Vector3(float(i) * 15.0, 0.025, -19.0), 180.0, 1.35)

static func _neighborhood(root: Node3D) -> void:
    var idx := 0
    var lots := [
        Vector3(-45, 0, -45), Vector3(-15, 0, -45), Vector3(15, 0, -45), Vector3(45, 0, -45),
        Vector3(-45, 0, -15), Vector3(-15, 0, -15), Vector3(15, 0, -15), Vector3(45, 0, -15),
        Vector3(-45, 0, 15), Vector3(-15, 0, 15), Vector3(15, 0, 15), Vector3(45, 0, 15),
        Vector3(-45, 0, 45), Vector3(-15, 0, 45), Vector3(15, 0, 45), Vector3(45, 0, 45)
    ]

    for p in lots:
        var file := BUILDINGS[idx % BUILDINGS.size()]
        _add(root, file, p, float((idx * 27) % 360), 1.55)
        idx += 1

        _add(root, "planter.glb", p + Vector3(-3.2, 0.03, 4.2), float((idx * 17) % 360), 1.0)
        _add(root, "planter.glb", p + Vector3(3.2, 0.03, 4.2), float((idx * 11) % 360), 1.0)

static func _trees(root: Node3D) -> void:
    var positions := [
        Vector3(-72, 0, -72), Vector3(-58, 0, -28), Vector3(-73, 0, 12), Vector3(-58, 0, 58),
        Vector3(72, 0, -72), Vector3(58, 0, -28), Vector3(73, 0, 12), Vector3(58, 0, 58),
        Vector3(-28, 0, 72), Vector3(28, 0, 72), Vector3(-28, 0, -72), Vector3(28, 0, -72)
    ]
    for i in positions.size():
        _add(root, "tree-large.glb" if i % 3 == 0 else "tree-small.glb", positions[i], float(i * 31), 1.25 if i % 3 == 0 else 1.15)

static func _add(root: Node3D, filename: String, position: Vector3, yaw: float, scale_factor: float) -> void:
    var packed = load(CITY_ROOT + filename)
    if packed == null:
        return
    var node = packed.instantiate()
    node.position = position
    node.rotation_degrees.y = yaw
    node.scale = Vector3.ONE * scale_factor
    root.add_child(node)
