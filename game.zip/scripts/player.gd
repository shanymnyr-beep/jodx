extends CharacterBody3D

@export var skin_path := ""

const WALK_SPEED := 4.8
const RUN_SPEED := 7.0
const JUMP_SPEED := 6.8
const GRAVITY := 18.0

var visual: Node3D
var camera_pivot: Node3D
var camera: Camera3D
var move_touch := Vector2.ZERO
var look_touch := false
var yaw := 0.0
var pitch := -12.0
var spawn_y := 0.0
var step_time := 0.0

func _ready() -> void:
    camera_pivot = $CameraPivot
    camera = $CameraPivot/Camera3D
    _load_character()
    _build_mobile_ui()

func _load_character() -> void:
    var scene = load("res://assets/characters/Model/characterMedium.fbx")
    if scene == null:
        $FallbackVisual.visible = true
        return

    visual = scene.instantiate()
    visual.name = "KenneyCharacter"
    visual.position = Vector3.ZERO
    visual.scale = Vector3.ONE
    add_child(visual)

    if skin_path != "":
        var tex = load(skin_path)
        if tex != null:
            _apply_skin(visual, tex)

    _fit_character_to_ground()

func _apply_skin(node: Node, tex: Texture2D) -> void:
    if node is MeshInstance3D:
        var mesh_instance := node as MeshInstance3D
        var material_count := mesh_instance.mesh.get_surface_count() if mesh_instance.mesh else 0
        if material_count > 0:
            for surface in material_count:
                var mat := mesh_instance.get_active_material(surface)
                var new_mat: StandardMaterial3D
                if mat is StandardMaterial3D:
                    new_mat = mat.duplicate()
                else:
                    new_mat = StandardMaterial3D.new()
                new_mat.albedo_texture = tex
                new_mat.roughness = 0.82
                mesh_instance.set_surface_override_material(surface, new_mat)

    for child in node.get_children():
        _apply_skin(child, tex)

func _fit_character_to_ground() -> void:
    if visual == null:
        return
    var min_y := INF
    var found := false
    for node in visual.get_children():
        var result := _find_mesh_min_y(node, Transform3D.IDENTITY)
        if result < INF:
            min_y = min(min_y, result)
            found = true
    if found:
        visual.position.y -= min_y

func _find_mesh_min_y(node: Node, parent_transform: Transform3D) -> float:
    var local_transform := parent_transform * node.transform if node is Node3D else parent_transform
    var min_y := INF
    if node is MeshInstance3D and node.mesh:
        var aabb := (node as MeshInstance3D).mesh.get_aabb()
        var corners := [
            Vector3(aabb.position.x, aabb.position.y, aabb.position.z),
            Vector3(aabb.end.x, aabb.position.y, aabb.position.z),
            Vector3(aabb.position.x, aabb.end.y, aabb.position.z),
            Vector3(aabb.end.x, aabb.end.y, aabb.end.z),
            Vector3(aabb.position.x, aabb.position.y, aabb.end.z)
        ]
        for c in corners:
            min_y = min(min_y, (local_transform * c).y)
    for child in node.get_children():
        min_y = min(min_y, _find_mesh_min_y(child, local_transform))
    return min_y

func _physics_process(delta: float) -> void:
    if not is_on_floor():
        velocity.y -= GRAVITY * delta
    else:
        if velocity.y < 0.0:
            velocity.y = -0.5

    var input_vec := Input.get_vector("move_left", "move_right", "move_forward", "move_back")
    if move_touch.length() > 0.1:
        input_vec = move_touch

    var local_dir := Vector3(input_vec.x, 0.0, input_vec.y)
    var dir := local_dir.rotated(Vector3.UP, yaw)
    var speed := RUN_SPEED if Input.is_action_pressed("run") else WALK_SPEED

    velocity.x = move_toward(velocity.x, dir.x * speed, 18.0 * delta)
    velocity.z = move_toward(velocity.z, dir.z * speed, 18.0 * delta)

    if input_vec.length() > 0.15:
        rotation.y = lerp_angle(rotation.y, atan2(-dir.x, -dir.z), 8.0 * delta)
        step_time += delta * (10.0 if speed == RUN_SPEED else 7.5)
        if visual:
            visual.position.y = 0.02 + abs(sin(step_time)) * 0.035
    elif visual:
        visual.position.y = lerp(visual.position.y, 0.0, 5.0 * delta)

    if Input.is_action_just_pressed("jump") and is_on_floor():
        velocity.y = JUMP_SPEED
    move_and_slide()

func _input(event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        look_touch = event.pressed and event.position.x > get_viewport().size.x * 0.45
    elif event is InputEventScreenDrag and event.position.x > get_viewport().size.x * 0.45:
        yaw -= event.relative.x * 0.004
        pitch = clamp(pitch - event.relative.y * 0.22, -32.0, 10.0)
        rotation.y = yaw
        camera_pivot.rotation_degrees.x = pitch

func _build_mobile_ui() -> void:
    var layer := $UI
    var hint := Label.new()
    hint.text = "WASD / Touch • Swipe right side to look • Jump"
    hint.position = Vector2(20, 18)
    hint.add_theme_font_size_override("font_size", 16)
    layer.add_child(hint)

    var left := _button("◀", Vector2(30, 545), Vector2(74, 70))
    var right := _button("▶", Vector2(190, 545), Vector2(74, 70))
    var up := _button("▲", Vector2(110, 475), Vector2(74, 70))
    var down := _button("▼", Vector2(110, 615), Vector2(74, 70))
    var jump := _button("JUMP", Vector2(1080, 545), Vector2(155, 80))
    for b in [left, right, up, down, jump]:
        layer.add_child(b)

    left.button_down.connect(func(): move_touch.x = -1.0)
    left.button_up.connect(func(): move_touch.x = 0.0)
    right.button_down.connect(func(): move_touch.x = 1.0)
    right.button_up.connect(func(): move_touch.x = 0.0)
    up.button_down.connect(func(): move_touch.y = -1.0)
    up.button_up.connect(func(): move_touch.y = 0.0)
    down.button_down.connect(func(): move_touch.y = 1.0)
    down.button_up.connect(func(): move_touch.y = 0.0)
    jump.pressed.connect(func():
        if is_on_floor():
            velocity.y = JUMP_SPEED
    )

func _button(text_value: String, pos: Vector2, size_value: Vector2) -> Button:
    var b := Button.new()
    b.text = text_value
    b.position = pos
    b.size = size_value
    b.focus_mode = Control.FOCUS_NONE
    b.add_theme_font_size_override("font_size", 18)
    return b
