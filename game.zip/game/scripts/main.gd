extends Node3D

const PLAYER_SCENE = preload("res://scenes/Player.tscn")
const CITY_SCRIPT = preload("res://scripts/city.gd")
const SKINS = [
    ["Human Male", "res://assets/characters/Skins/humanMaleA.png"],
    ["Human Female", "res://assets/characters/Skins/humanFemaleA.png"],
    ["Zombie Male", "res://assets/characters/Skins/zombieMaleA.png"],
    ["Zombie Female", "res://assets/characters/Skins/zombieFemaleA.png"]
]

var menu: Control

func _ready():
    _show_character_select()

func _show_character_select():
    menu = Control.new()
    menu.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(menu)
    var bg = ColorRect.new()
    bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    bg.color = Color("11141b")
    menu.add_child(bg)
    var title = Label.new()
    title.text = "CITY WANDERER"
    title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    title.position = Vector2(0, 65)
    title.size = Vector2(1280, 70)
    title.add_theme_font_size_override("font_size", 42)
    menu.add_child(title)
    var sub = Label.new()
    sub.text = "Choose your character"
    sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    sub.position = Vector2(0, 135)
    sub.size = Vector2(1280, 40)
    sub.add_theme_font_size_override("font_size", 22)
    menu.add_child(sub)
    var row = HBoxContainer.new()
    row.position = Vector2(120, 230)
    row.size = Vector2(1040, 170)
    row.add_theme_constant_override("separation", 22)
    menu.add_child(row)
    for skin in SKINS:
        var b = Button.new()
        b.text = skin[0]
        b.custom_minimum_size = Vector2(244, 150)
        b.add_theme_font_size_override("font_size", 20)
        b.pressed.connect(_start_game.bind(skin[1]))
        row.add_child(b)
    var info = Label.new()
    info.text = "Explore the suburban city • Walk • Run • Jump"
    info.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    info.position = Vector2(0, 475)
    info.size = Vector2(1280, 50)
    info.add_theme_font_size_override("font_size", 18)
    menu.add_child(info)

func _start_game(skin_path: String):
    if is_instance_valid(menu):
        menu.queue_free()
    var world = Node3D.new()
    world.name = "World"
    add_child(world)
    CITY_SCRIPT.build_city(world)
    var player = PLAYER_SCENE.instantiate()
    player.position = Vector3(0, 2.0, 0)
    player.set("skin_path", skin_path)
    world.add_child(player)
