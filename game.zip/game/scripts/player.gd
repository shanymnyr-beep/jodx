extends CharacterBody3D

@export var skin_path := ""
const SPEED = 5.5
const RUN_SPEED = 8.0
const JUMP = 7.0
var visual: Node3D
var camera_pivot: Node3D
var camera: Camera3D
var move_touch := Vector2.ZERO
var yaw := 0.0
var pitch := -12.0

func _ready():
    camera_pivot = $CameraPivot
    camera = $CameraPivot/Camera3D
    _load_character()
    _build_mobile_ui()

func _load_character():
    var packed = load("res://assets/characters/Model/characterMedium.fbx")
    if packed:
        visual = packed.instantiate()
        visual.position = Vector3(0, 0, 0)
        visual.scale = Vector3.ONE * 1.0
        add_child(visual)
        if skin_path != "":
            var tex = load(skin_path)
            if tex:
                _apply_texture(visual, tex)

func _apply_texture(node, tex):
    for c in node.get_children():
        if c is MeshInstance3D:
            var mat = StandardMaterial3D.new()
            mat.albedo_texture = tex
            mat.roughness = 0.9
            c.material_override = mat
        _apply_texture(c, tex)

func _physics_process(delta):
    if not is_on_floor():
        velocity.y -= 18.0 * delta
    var input_vec = Input.get_vector("move_left", "move_right", "move_forward", "move_back")
    if move_touch.length() > 0.1:
        input_vec = move_touch
    var dir = Vector3(input_vec.x, 0, input_vec.y)
    dir = dir.rotated(Vector3.UP, rotation.y)
    var speed = RUN_SPEED if Input.is_key_pressed(KEY_SHIFT) else SPEED
    velocity.x = move_toward(velocity.x, dir.x * speed, 20.0 * delta)
    velocity.z = move_toward(velocity.z, dir.z * speed, 20.0 * delta)
    if (Input.is_action_just_pressed("jump") or Input.is_key_pressed(KEY_SPACE)) and is_on_floor():
        velocity.y = JUMP
    move_and_slide()

func _input(event):
    if event is InputEventScreenDrag:
        if event.position.x > get_viewport().size.x * 0.45:
            yaw -= event.relative.x * 0.004
            pitch = clamp(pitch - event.relative.y * 0.25, -35.0, 10.0)
            rotation.y = yaw
            camera_pivot.rotation_degrees.x = pitch

func _build_mobile_ui():
    var layer = $UI
    var hint = Label.new()
    hint.text = "WASD / Touch • Swipe right side to look • Jump"
    hint.position = Vector2(20, 18)
    hint.add_theme_font_size_override("font_size", 16)
    layer.add_child(hint)
    var left = Button.new(); left.text = "◀"; left.position = Vector2(35, 560); left.size = Vector2(75, 75)
    var right = Button.new(); right.text = "▶"; right.position = Vector2(195, 560); right.size = Vector2(75, 75)
    var up = Button.new(); up.text = "▲"; up.position = Vector2(115, 500); up.size = Vector2(75, 75)
    var down = Button.new(); down.text = "▼"; down.position = Vector2(115, 580); down.size = Vector2(75, 75)
    var jump = Button.new(); jump.text = "JUMP"; jump.position = Vector2(1080, 560); jump.size = Vector2(150, 80)
    for b in [left,right,up,down,jump]: layer.add_child(b)
    left.button_down.connect(func(): move_touch.x = -1)
    left.button_up.connect(func(): move_touch.x = 0)
    right.button_down.connect(func(): move_touch.x = 1)
    right.button_up.connect(func(): move_touch.x = 0)
    up.button_down.connect(func(): move_touch.y = -1)
    up.button_up.connect(func(): move_touch.y = 0)
    down.button_down.connect(func(): move_touch.y = 1)
    down.button_up.connect(func(): move_touch.y = 0)
    jump.pressed.connect(func(): if is_on_floor(): velocity.y = JUMP)
